# 设置项清单（完整字段与取值范围）

> 字段名即 `sollin.json` → `settings` 下的真实键名；下游设计请按此字段设计控件。
> 「默认值」取自真实用户数据快照。设置抽屉当前按 Tab 分组显示。

## 外观与字体

| 字段 | 类型 | 默认值 | 说明 |
|---|---|---|---|
| `theme` | string | system | `system` / `light` / `dark` |
| `accent` | string | #e55b45 | 主题强调色，十六进制色值 |
| `animationEnabled` | bool | true |  |
| `uiFontSize` | int | 16 | 界面字号，14–20 |
| `uiFont` | string | "" | 自定义字体路径，空 = 系统默认 |
| `importedUiFont` | null | — |  |

## 快捷键

| 字段 | 类型 | 默认值 | 说明 |
|---|---|---|---|
| `hotkeys` | object | 4 项 | 见下</details> |
| `hotkeys.localEnabled` | bool | true | |
| `hotkeys.globalEnabled` | bool | false | |
| `hotkeys.local` | object | 4 项 | 子分组 |
| `hotkeys.local.togglePlay` | string | Mod+F5 | |
| `hotkeys.local.previous` | string | Mod+ArrowLeft | |
| `hotkeys.local.next` | string | Mod+ArrowRight | |
| `hotkeys.local.focusSearch` | string | F1 | |
| `hotkeys.global` | object | 8 项 | 子分组 |
| `hotkeys.global.togglePlay` | string | Mod+Alt+F5 | |
| `hotkeys.global.previous` | string | Mod+Alt+ArrowLeft | |
| `hotkeys.global.next` | string | Mod+Alt+ArrowRight | |
| `hotkeys.global.volumeUp` | string | Mod+Alt+ArrowUp | |
| `hotkeys.global.volumeDown` | string | Mod+Alt+ArrowDown | |
| `hotkeys.global.toggleDesktopLyric` | string | Mod+Alt+0 | |
| `hotkeys.global.toggleDesktopLyricLock` | string | Mod+Alt+- | |
| `hotkeys.global.toggleDesktopLyricAlwaysOnTop` | string | Mod+Alt+= | |

## 播放器与音质

| 字段 | 类型 | 默认值 | 说明 |
|---|---|---|---|
| `preferredQuality` | string | flac | `flac` / `320k` / `128k` |
| `playMode` | string | listLoop | `listLoop` / `singleLoop` / `shuffle` / `sequential` |
| `volume` | float | 0.78 | 0–1 |
| `muted` | bool | false |  |
| `playbackRate` | int | 1 | 倍速档位（1 / 1.25 / 1.5 / 2 …） |
| `preservesPitch` | bool | true |  |
| `loudnessNormalization` | string | off | `off` / `track` / `album` |
| `loudnessPreampDb` | int | 0 | −12 – +12 dB |
| `loudnessPreventClipping` | bool | true |  |
| `fadeEnabled` | bool | false |  |
| `fadeInMs` | int | 300 |  |
| `fadeOutMs` | int | 200 |  |
| `audioOutputDeviceId` | string | default |  |
| `autoSkipOnError` | bool | true | 解析失败自动跳下一首 |
| `sleepTimerMinutes` | int | 0 | 0 = 关闭；常见档位 15/30/60/90 |
| `sleepTimerWaitPlayEnd` | bool | true |  |
| `showTaskbarProgress` | bool | true |  |

## 音频效果

| 字段 | 类型 | 默认值 | 说明 |
|---|---|---|---|
| `audioEffects` | object | 9 项 | 见下</details> |
| `audioEffects.visualization` | bool | false | |
| `audioEffects.equalizer` | object | 10 项 | 子分组 |
| `audioEffects.equalizer.31` | int | 0 | |
| `audioEffects.equalizer.62` | int | 0 | |
| `audioEffects.equalizer.125` | int | 0 | |
| `audioEffects.equalizer.250` | int | 0 | |
| `audioEffects.equalizer.500` | int | 0 | |
| `audioEffects.equalizer.1000` | int | 0 | |
| `audioEffects.equalizer.2000` | int | 0 | |
| `audioEffects.equalizer.4000` | int | 0 | |
| `audioEffects.equalizer.8000` | int | 0 | |
| `audioEffects.equalizer.16000` | int | 0 | |
| `audioEffects.reverbPreset` | string | "" | |
| `audioEffects.reverbDry` | int | 1 | |
| `audioEffects.reverbWet` | int | 0 | |
| `audioEffects.spatialEnabled` | bool | false | |
| `audioEffects.spatialDistance` | int | 5 | |
| `audioEffects.spatialSpeed` | int | 25 | |
| `audioEffects.pitch` | int | 1 | |

## 歌词（经典详情页）

| 字段 | 类型 | 默认值 | 说明 |
|---|---|---|---|
| `lyricFontSize` | int | 48 | 32–96 px |
| `lyricFontWeight` | int | 700 | 400–900 |
| `lyricLineSpacing` | int | 16 | 0–48 px |
| `lyricInactiveOpacity` | float | 0.2 | 0–1（非当前行透明度） |
| `lyricBlurEnabled` | bool | false |  |
| `lyricTextAlign` | string | left | `left` / `center` / `right` |
| `lyricColor` | null | — | null = 跟随封面色；也可指定色值 |

## 背景

| 字段 | 类型 | 默认值 | 说明 |
|---|---|---|---|
| `playerBackgroundMode` | string | static-flow | `static-flow` / `dynamic-flow` / `solid` 等 |

## 音源

| 字段 | 类型 | 默认值 | 说明 |
|---|---|---|---|
| `builtinSourceEnabled` | bool | false | 内置音源总开关 |
| `platformSources` | object | 0 项 | 见下</details> |

## 其他字段

| 字段 | 类型 | 默认值 |
|---|---|---|
| `checkUpdatesOnStartup` | bool | true |
| `checkSourceUpdatesOnStartup` | bool | true |
| `cloudSyncEnabled` | bool | true |
| `songCacheLimitMb` | int | 2048 |
| `cachePath` | null | — |
| `taskbarPreview` | string | default |
| `taskbarPreviewImage` | null | — |
| `desktopLyric` | object | 30 项 |
| `menuBarLyric` | bool | false |
| `wallpaper` | object | 16 项 |
| `download` | object | 19 项 |
| `closeAction` | string | ask |
| `detailFxMode` | bool | true |
| `detailFx` | object | 43 项 |

## 说明

- 设置变更**即时生效**并持久化（部分高频操作有节流：滑块拖动只在停手 500ms 后落盘）
- 设置抽屉当前分 Tab：外观 / 播放 / 歌词 / 音效 / 快捷键 / 音源 / 其他
- 主题支持 `system`（跟随系统）；强调色会同时影响按钮、进度条、歌词高亮、动效 accent
- 字体导入支持本地字体文件，导入后写入 `uiFont` + `importedUiFont`
- 快捷键录入为「录制式」，见 `02-shortcuts.md`