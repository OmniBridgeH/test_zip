// 全局状态（对应原型 core.js 的 S 与 ACT）。所有页面通过 context.app 读取，修改后 notifyListeners。
// 接口对接时：把 mock 读取换成 Repository 调用即可，UI 不需要改。
import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../data/mock.dart';
import '../data/models.dart';
import 'tokens.dart';

class Settings {
  bool trans = true, roma = false, conv = false, blur = true, glow = true;
  double lfs = 26, ltfs = 15, lgap = 10, loff = 0;
  bool fade = true, autoplay = false, autoOpen = false, keepAwake = true;
  bool smart = true, gradual = true, crossScript = true, crossPlat = true, autoNext = true;
  bool nQ = true, nS = true, nA = false, allowDown = true;
  bool floatLyric = false, floatLock = false, btLyric = true, sbLyric = false;
  double dlConc = 3;
  bool dlCover = true, dlLyric = true, wifiOnly = true, cache = true, vinylSpin = true, haptics = true, pitch = true;
  bool finishSong = true, fadeStop = true, cloudSync = true, autoBackup = true, crash = true, navAutoMin = true, clipDetect = true;
  bool reduceMotion = false, standbyAuto = true, autoDowngrade = true, mobileLow = true;
  String onlineQ = 'SQ', dlQ = 'Hi-Res', mode = '列表循环', fontSize = '标准';
}

class AppState extends ChangeNotifier {
  // ---------- 鉴权 ----------
  bool authed = false, agreed = false, seenDisclaimer = false;
  String authPage = 'disclaimer'; // disclaimer | login | register | forgot | versionDisabled

  // ---------- 外观 ----------
  ThemeMode themeMode = ThemeMode.dark;
  int accent = 0;
  String bar = 'liquid', skin = 'spring', bg = 'flow', tone = 'dark', appIcon = 'gold', font = 'system';
  double dim = 45;
  String amWave = 'spring', particle = 'galaxy';
  final homeMods = <MapEntry<String, bool>>[
    const MapEntry('custom', true), const MapEntry('mypl', true), const MapEntry('quick', true),
    const MapEntry('tabs', true), const MapEntry('platrec', true),
  ];
  final set = Settings();

  // ---------- 导航 ----------
  int tab = 0; // 0 发现 1 搜索 2 每日 3 音乐库 4 我的
  bool navMin = false, searchFocus = false;
  int? clipSong; // 剪贴板里识别到的分享口令（歌曲 id）

  // ---------- 播放 ----------
  int cur = 0;
  bool playing = true;
  double vol = .7, speed = 1;
  String mode = 'loop'; // loop | one | shuffle | order
  String quality = 'SQ';
  int timer = 0;
  String? castDev;
  List<int> queue = List.generate(16, (i) => i);
  String queueName = '深夜城市漫游 · 霓虹与雨';
  final liked = <int>{0, 4, 7, 12, 17};
  final pos = ValueNotifier<double>(31);
  Timer? _clock;
  DateTime _last = DateTime.now();

  // ---------- 内容 ----------
  String plat = 'netease', script = 'auto';
  final platLogin = <String, String>{'netease': '小栗子'};
  final scripts = [...scriptsSeed];
  final myPlaylists = [...myPlaylistsSeed];
  final history = <String>['夜航星图', '雾港', 'Lo-fi', '玻璃海'];
  final disliked = <int>{};
  bool loading = false;
  String homeTab = '精选', libSeg = '我喜欢';
  int myPlSeg = 0;
  final crossOrder = <String>['qq', 'kugou', 'kuwo', 'migu'];
  final scriptOrder = <String, List<String>>{};
  List<double> eq = [...eqPresets['流行']!];
  String eqPreset = '流行';
  bool eqOn = true;
  int unread = 1;

  AppState() {
    for (final p in platforms) {
      scriptOrder[p.id] = scripts.where((s) => s.platforms.contains(p.id)).map((s) => s.id).toList();
    }
    _clock = Timer.periodic(const Duration(milliseconds: 100), (_) => _tick());
  }

  // ---------- 派生 ----------
  Pal pal(Brightness platformBrightness) {
    final dark = themeMode == ThemeMode.system ? platformBrightness == Brightness.dark : themeMode == ThemeMode.dark;
    return Pal.of(dark, accents[accent]);
  }

  Song get song => songs[cur];
  Platform get platform => platformBy(plat);
  bool isIn(String pid) => platLogin.containsKey(pid);
  List<Script> scriptsOf(String pid) {
    final order = scriptOrder[pid] ?? [];
    final l = scripts.where((s) => s.platforms.contains(pid)).toList();
    l.sort((a, b) => order.indexOf(a.id).compareTo(order.indexOf(b.id)));
    return l;
  }

  ({String name, int ms, int ok}) get curScript {
    if (script == 'auto') {
      final l = scriptsOf(plat);
      return (name: '自动选择', ms: l.isEmpty ? 0 : l.first.ms, ok: 99);
    }
    final s = scripts.firstWhere((x) => x.id == script, orElse: () => scripts.first);
    return (name: s.name, ms: s.ms, ok: s.ok);
  }

  int get lyricIndex {
    final p = pos.value + set.loff;
    var k = 0;
    for (var i = 0; i < lyrics.length; i++) {
      if (lyrics[i].t <= p) k = i;
    }
    return k;
  }

  /// 当前行内进度 0..1（只有行时间时按行时长 × 0.92 均匀插值）。
  double get lineProgress {
    final l = lyrics[lyricIndex];
    return ((pos.value + set.loff - l.t) / (l.d * .92)).clamp(0, 1);
  }

  /// 模拟节拍包络 0..1（112 BPM）。
  double beat([double? at]) {
    final t = at ?? pos.value;
    final ph = (t * 112 / 60) % 1;
    return math.pow(1 - ph, 3).toDouble();
  }

  List<int> listOf(String k) {
    switch (k) {
      case 'hot':
        return [0, 2, 4, 5, 17, 7, 11, 16, 14, 12];
      case 'daily':
        final l = List.generate(songs.length, (i) => i)..sort((a, b) => ((a * 37 + 11) % 24).compareTo((b * 37 + 11) % 24));
        return l.where((i) => !disliked.contains(i)).toList();
      case 'like':
        return liked.toList();
      case 'local':
        final l = [...songs]..sort((a, b) => a.title.compareTo(b.title));
        return l.map((s) => s.id).toList();
      default:
        return List.generate(songs.length, (i) => i);
    }
  }

  // ---------- 播放控制 ----------
  void _tick() {
    final now = DateTime.now();
    final dt = now.difference(_last).inMicroseconds / 1e6;
    _last = now;
    if (!playing) return;
    var p = pos.value + dt * speed;
    if (p >= song.dur) {
      if (mode == 'one') {
        p = 0;
      } else {
        _step(1, notify: true);
        return;
      }
    }
    pos.value = p;
  }

  void play(int id, {String? list, String? name}) {
    if (list != null) {
      queue = listOf(list);
      if (name != null) queueName = name;
    }
    if (!queue.contains(id)) queue.insert(math.min(queue.indexOf(cur) + 1, queue.length), id);
    cur = id;
    pos.value = 0;
    playing = true;
    notifyListeners();
  }

  void playAll(String list, {bool shuffle = false, String? name}) {
    queue = listOf(list);
    if (shuffle) queue.shuffle(math.Random(7));
    if (name != null) queueName = name;
    if (queue.isEmpty) return;
    cur = queue.first;
    pos.value = 0;
    playing = true;
    if (shuffle) mode = 'shuffle';
    notifyListeners();
  }

  void toggle() {
    playing = !playing;
    notifyListeners();
  }

  void next() => _step(1);
  void prev() {
    if (pos.value > 3) {
      pos.value = 0;
      notifyListeners();
      return;
    }
    _step(-1);
  }

  void _step(int d, {bool notify = true}) {
    final i = queue.indexOf(cur);
    if (mode == 'shuffle') {
      cur = queue[(i + 3 + math.Random().nextInt(math.max(1, queue.length - 2))) % queue.length];
    } else {
      cur = queue[(i + d + queue.length) % queue.length];
    }
    pos.value = 0;
    if (notify) notifyListeners();
  }

  void seek(double sec) {
    pos.value = sec.clamp(0, song.dur.toDouble());
  }

  void cycleMode() {
    const order = ['loop', 'one', 'shuffle', 'order'];
    mode = order[(order.indexOf(mode) + 1) % order.length];
    notifyListeners();
  }

  String get modeName => const {'loop': '列表循环', 'one': '单曲循环', 'shuffle': '随机播放', 'order': '顺序播放'}[mode]!;

  bool toggleLike(int id) {
    final on = !liked.contains(id);
    on ? liked.add(id) : liked.remove(id);
    notifyListeners();
    return on;
  }

  void playNext(int id) {
    queue.remove(id);
    queue.insert(math.min(queue.indexOf(cur) + 1, queue.length), id);
    notifyListeners();
  }

  void reorderQueue(int from, int to) {
    final id = queue.removeAt(from);
    queue.insert(to > from ? to - 1 : to, id);
    notifyListeners();
  }

  // ---------- 通用修改 ----------
  void update(VoidCallback f) {
    f();
    notifyListeners();
  }

  Future<void> switchPlatform(String id) async {
    if (id == plat) return;
    plat = id;
    script = 'auto';
    loading = true;
    notifyListeners();
    await Future.delayed(const Duration(milliseconds: 750));
    loading = false;
    notifyListeners();
  }

  Future<void> reload() async {
    loading = true;
    notifyListeners();
    await Future.delayed(const Duration(milliseconds: 750));
    loading = false;
    notifyListeners();
  }

  void moveHomeMod(int from, int to) {
    final e = homeMods.removeAt(from);
    homeMods.insert(to, e);
    notifyListeners();
  }

  bool homeOn(String k) => homeMods.firstWhere((e) => e.key == k).value;
  void setHomeMod(String k, bool v) {
    final i = homeMods.indexWhere((e) => e.key == k);
    homeMods[i] = MapEntry(k, v);
    notifyListeners();
  }

  void login(String pid, String name) {
    platLogin[pid] = name;
    notifyListeners();
  }

  void logout(String pid) {
    platLogin.remove(pid);
    notifyListeners();
  }

  @override
  void dispose() {
    _clock?.cancel();
    pos.dispose();
    super.dispose();
  }
}

/// 让任意子树拿到 AppState，并在其变化时重建。
class AppScope extends InheritedNotifier<AppState> {
  const AppScope({super.key, required AppState state, required super.child}) : super(notifier: state);
  static AppState of(BuildContext c) => c.dependOnInheritedWidgetOfExactType<AppScope>()!.notifier!;
  static AppState read(BuildContext c) => c.getInheritedWidgetOfExactType<AppScope>()!.notifier!;
}

/// 配色作用域：播放器、深色 Sheet 用 [Pal.forceDark] 覆盖。
class PalScope extends InheritedWidget {
  final Pal pal;
  const PalScope({super.key, required this.pal, required super.child});
  @override
  bool updateShouldNotify(PalScope old) => old.pal.dark != pal.dark || old.pal.accent != pal.accent;
}

extension Ctx on BuildContext {
  AppState get app => AppScope.of(this);
  AppState get appRead => AppScope.read(this);
  Pal get pal => dependOnInheritedWidgetOfExactType<PalScope>()!.pal;
}
