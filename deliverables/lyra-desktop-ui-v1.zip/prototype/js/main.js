/* 入口：窗口缩放适配、原型目录（跳到任意页面 / 状态）、启动。 */
function fit() {
  const st = document.getElementById('stage'), win = document.getElementById('win');
  const W = D.mini ? 380 : 1440, H = D.mini ? 104 : 900;
  const sc = document.body.classList.contains('real') ? 1 : Math.min((innerWidth - 48) / W, (innerHeight - 110) / H, 1);
  win.style.transform = `scale(${sc})`; st.style.width = W * sc + 'px'; st.style.height = H * sc + 'px';
}
const _render = render;
render = function () {
  _render(); fit();
  if (D.big) requestAnimationFrame(() => {
    const wall = document.querySelector('.big-wall'), band = wall && wall.querySelector('.band.on'), f = band && band.querySelector('.bcard.focus');
    if (!wall || !band || !f) return;
    wall.style.transform = `translateY(${-band.offsetTop + 24}px)`;
    band.querySelector('.b-row').style.transform = `translateX(${Math.min(0, -(f.offsetLeft - 60))}px)`;
  });
};
const JUMPS = [
  ['窗口与导航', [
    ['推荐 · 网易云已登录', () => {}], ['推荐 · QQ 音乐未登录', () => { D.plat = 'qq'; }], ['推荐 · 榜单 Tab', () => { D.homeTab = '榜单'; }],
    ['平台 → 解析脚本选择器', () => { D.picker = true; }], ['命令面板（Ctrl+K）', () => { D.pal = true; }], ['命令面板 · 输入中', () => { D.pal = true; D.q = '雾'; }],
    ['侧边栏收起', () => { D.sb = true; }], ['右键菜单 · 歌曲', () => { go('collection', { id:0 }); D.ctx = { k:'song', id:4, x:620, y:360 }; }],
    ['多选 + 批量操作', () => { go('favorites'); [0, 4, 7, 12].forEach(i => D.sel.add(i)); }], ['关闭行为询问', () => { D.dlg = 'close'; }],
  ]],
  ['页面', [
    ['排行榜', () => go('charts')], ['歌单广场', () => go('square')], ['歌单详情', () => go('collection', { id:0 })], ['我喜欢的音乐', () => go('collection', { id:100 })],
    ['歌手', () => go('artist', { id:0 })], ['搜索结果 · 单曲', () => { D.q = '雾港'; go('search', { q:'雾港' }); }], ['搜索结果 · 歌词（酷狗不支持）', () => { D.q = '星'; go('search', { q:'星' }); D.sType = '歌词'; }],
    ['搜索 · 无结果', () => { D.q = 'xyzabc'; go('search', { q:'xyzabc' }); }], ['收藏 + 重复项面板', () => { go('favorites'); D.dupes = true; D.rp = 'dupes'; D.rpOpen = true; }],
    ['本地音乐', () => go('local')], ['本地音乐 · 编辑标签', () => { go('local'); D.editTag = 4; D.rp = 'tag'; D.rpOpen = true; }], ['本地音乐 · 专辑视图', () => { go('local'); D.localView = '专辑'; }],
    ['智能歌单', () => go('smart')], ['最近播放', () => go('history')], ['听歌统计', () => go('stats')], ['平台与解析脚本', () => go('sources')], ['404', () => go('nowhere')],
  ]],
  ['设置', [
    ['设置 · 通用', () => { go('settings'); D.setCat = '通用'; }], ['设置 · 外观', () => { go('settings'); D.setCat = '外观'; }], ['设置 · 播放与音质', () => { go('settings'); D.setCat = '播放与音质'; }],
    ['设置 · 音效', () => { go('settings'); D.setCat = '音效'; }], ['设置 · 快捷键', () => { go('settings'); D.setCat = '快捷键'; }], ['设置 · 搜索「歌词」', () => { go('settings'); D.setQ = '歌词'; }],
  ]],
  ['弹出层', [
    ['账号卡', () => { D.pop = { v:'user', style:'right:150px;top:52px' }; }], ['云同步 · 正常', () => { D.pop = { v:'sync', style:'right:240px;top:52px' }; }], ['云同步 · 冲突', () => { D.sync = 'conflict'; D.pop = { v:'sync', style:'right:240px;top:52px' }; }],
    ['音质', () => { D.pop = { v:'quality', style:'right:330px;bottom:94px' }; }], ['输出设备', () => { D.pop = { v:'output', style:'right:200px;bottom:94px' }; }],
    ['新建歌单', () => { D.dlg = 'newPl'; }], ['导入歌单', () => { D.dlg = 'importPl'; D.dlgVal = 'https://y.qq.com/n/ryqq/playlist/8837261540'; D.dlgP = 1; }], ['平台扫码登录', () => { D.dlg = 'platLogin'; D.dlgPlat = 'qq'; }],
  ]],
  ['播放', [
    ['播放页 · 经典', () => { D.view = 'classic'; }], ['播放页 · 动效', () => { D.view = 'fx'; }], ['动效 · 歌单架', () => { D.view = 'fx'; D.shelf = true; }], ['动效 · 歌单架展开', () => { D.view = 'fx'; D.shelf = true; D.shelfOpen = true; }],
    ['动效 · 事件视界', () => { D.view = 'fx'; D.fx = 'disk'; S.particle = 'disk'; }], ['迷你模式', () => { D.mini = true; }], ['桌面歌词', () => { D.deskLyric = true; }],
  ]],
  ['探索', [['大屏模式（Exploring）', () => { D.big = true; }], ['大屏 · 焦点在推荐', () => { D.big = true; D.bf = { b:3, i:2 }; }]]],
];
const FLAT = JUMPS.flatMap(([g, l]) => l.map(([n, fn]) => ({ n, fn })));
let curJump = '推荐 · 网易云已登录';
function reset() { Object.assign(D, { route:{ p:'discover', a:{} }, back:[], fwd:[], sb:false, rp:'queue', rpOpen:true, plat:'netease', script:'auto', login:{ netease:'小栗子' }, picker:false, pal:false, q:'', pop:null, ctx:null, dlg:null, view:null, shelf:false, shelfOpen:false, mini:false, big:false, deskLyric:false, sync:'ok', homeTab:'精选', sType:'单曲', sPlat:'all', setQ:'', setCat:'通用', dupes:false, editTag:null, localView:'歌曲', fx:'galaxy', idle:false }); D.sel.clear(); S.particle = 'galaxy'; }
function jump(n) { const j = FLAT.find(x => x.n === n); if (!j) return; reset(); j.fn(); curJump = n; D._stag = true; render(); }
function buildDir() {
  const el = document.getElementById('dir');
  el.innerHTML = `<button class="dir-tg" onclick="document.body.classList.toggle('dir-open')">${ic('grid')}<span>原型目录</span></button>
    <div class="dir-p"><h3>Lyra（暂名）桌面端原型</h3><p>Electron · 1440×900 · 网易云 / QQ / 酷狗</p>
      <div class="dir-o"><button onclick="D.theme=D.theme==='dark'?'light':'dark';render()">深浅主题</button><button onclick="document.body.classList.toggle('real');fit()">实际大小</button>${ACCENTS.map((a, i) => `<button style="width:22px;padding:0;background:${a.c}" onclick="D.accent=${i};render()" title="${a.n}"></button>`).join('')}</div>
      ${JUMPS.map(([g, l]) => `<h4>${g}</h4>${l.map(([n]) => `<a data-j="${n}">${n}</a>`).join('')}`).join('')}</div>`;
  el.onclick = e => { const a = e.target.closest('[data-j]'); if (a) jump(a.dataset.j); };
}
function syncDir() { document.querySelectorAll('#dir [data-j]').forEach(a => a.classList.toggle('on', a.dataset.j === curJump)); }
window.addEventListener('DOMContentLoaded', () => {
  buildDir(); bindEvents();
  const qs = new URLSearchParams(location.search);
  if (qs.get('theme')) D.theme = qs.get('theme');
  if (qs.get('go')) jump(qs.get('go')); else render();
  if (qs.get('dir') === '1') document.body.classList.add('dir-open');
  requestAnimationFrame(tick);
  // 桌面歌词拖动
  const dl = document.getElementById('desklyric'); let dg = null;
  dl.addEventListener('pointerdown', e => { if (D.deskLock || e.target.closest('button')) return; dg = { x:e.clientX - dl.offsetLeft, y:e.clientY - dl.offsetTop }; dl.setPointerCapture(e.pointerId); });
  dl.addEventListener('pointermove', e => { if (dg) { dl.style.left = e.clientX - dg.x + 'px'; dl.style.top = e.clientY - dg.y + 'px'; dl.style.transform = 'none'; } });
  dl.addEventListener('pointerup', () => { dg = null; });
  dl.addEventListener('click', e => { const b = e.target.closest('[data-dl]'); if (!b) return; const a = b.dataset.dl; if (a === 'lock') D.deskLock = !D.deskLock; if (a === 'close') D.deskLyric = false; if (a === 'prev') ACT.prev(); if (a === 'next') ACT.next(); if (a === 'toggle') ACT.toggle(); if (a === 'font') { D.dlSize = ((D.dlSize || 0) + 1) % 3; dl.dataset.size = D.dlSize; toast('桌面歌词字号 ' + ['标准', '大', '特大'][D.dlSize]); } render(); });
});
window.addEventListener('resize', fit);
window.__lyra = { D, jump, render, JUMPS:FLAT.map(x => x.n) };
