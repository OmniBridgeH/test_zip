/* 播放页（经典 / 动效）、迷你模式、桌面歌词、大屏模式（探索）。 */
const FX_PRESETS = [{ k:'galaxy', n:'旋涡星系', c:'宇宙' }, { k:'disk', n:'事件视界', c:'宇宙' }, { k:'globe', n:'全息地球', c:'科技' }, { k:'gyro', n:'陀螺核心', c:'科技' }];
const FX_MORE = ['金缮', '墨韵', '超立方', '磷光示波', '神经花火', '雾中光柱', '戴森云', '托卡马克', '虫洞', '丝绸', '星球', '唱片'];
const lyrLines = (cls = '') => `<div class="plyr ${cls}" data-lyr data-mode="stagger">${LYRICS.map((l, i) => `<p data-li="${i}" data-act="seekLine" data-i="${i}" style="font-size:${cls ? '' : D.set.lfs + 'px'};font-weight:${D.set.lfw};margin-bottom:${D.set.lgap}px;text-align:${D.set.lalign}"><span class="w">${l.o}</span>${D.set.trans ? `<small>${l.tr}</small>` : ''}</p>`).join('')}</div>`;
function pControls(s) {
  return `<div class="pc"><div class="pc-prog"><span data-b="pos">${fmt(D.pos)}</span><div class="prog lg" data-seek="song"><i class="buf"></i><i class="fill" style="width:${D.pos / s.dur * 100}%"></i><b class="th" style="left:${D.pos / s.dur * 100}%"></b></div><span>${fmt(s.dur)}</span></div>
    <div class="pc-row"><div class="pc-l"><button class="heart ${D.liked.has(s.id) ? 'on' : ''}" data-act="like" data-id="${s.id}">${ic(D.liked.has(s.id) ? 'heartf' : 'heart')}</button><button class="ib" data-act="toast" data-msg="已加入下载" data-icon="download">${ic('download')}</button><button class="qchip" data-act="pop" data-v="quality">${D.quality}</button></div>
      <div class="pc-c"><button class="ib" data-act="mode">${ic({ loop:'repeat', one:'repeat1', shuffle:'shuffle', order:'order' }[D.mode])}</button><button class="ib lg" data-act="prev">${ic('prev')}</button><button class="pc-play" data-act="toggle">${ic(D.playing ? 'pause' : 'play')}</button><button class="ib lg" data-act="next">${ic('next')}</button><button class="ib ${D.deskLyric ? 'acc' : ''}" data-act="tgDeskLyric">${ic('lyric')}</button></div>
      <div class="pc-r"><button class="ib" data-act="pop" data-v="output">${ic('volume')}</button><div class="vol"><div class="prog sm" data-seek="vol"><i class="fill" style="width:${D.vol * 100}%"></i><b class="th" style="left:${D.vol * 100}%"></b></div></div></div></div></div>`;
}
function PLAYER() {
  const s = song(), fx = D.view === 'fx';
  const top = `<div class="pv-top drag"><button class="ib nodrag" data-act="closePlayer" title="Esc">${ic('down')}</button>
    <div class="pv-seg nodrag">${seg(['经典', '动效'], fx ? '动效' : '经典', 'pvMode')}</div>
    <div class="pv-r nodrag">${fx ? `<button class="ib ${D.shelf ? 'acc' : ''}" data-act="tgShelf" title="歌单架（右键）">${ic('layers')}</button>` : ''}<button class="ib" data-act="toBig" title="大屏模式（探索）">${ic('tv')}</button><button class="ib" data-act="goSetFromPlayer" title="设置">${ic('gear')}</button><button class="ib" data-act="tgMax">${ic('expand')}</button></div></div>`;
  if (!fx) return `<div class="player classic ${D.playing ? '' : 'paused'}"><div class="pv-bg"><div class="flow">${[0, 50, 300].map((d, i) => `<i style="background:radial-gradient(circle,hsl(${(s.h + d) % 360} 70% ${[52, 40, 46][i]}%),transparent 65%)"></i>`).join('')}</div></div>${top}
    <div class="pv-main"><div class="pv-art"><div class="cv" style="${coverStyle(s.h, s.v)}"></div><div class="pv-ti"><h1>${s.t}</h1><p><a data-act="goArtist">${s.a}</a> · ${s.al} · ${pb(platBy(pidOf(s.id)), 16)} ${platBy(pidOf(s.id)).n}</p></div></div>
      <div class="pv-lyr">${lyrLines()}</div>
      <div class="pv-q"><div class="rp-h"><b>接下来播放</b><button data-act="toast" data-msg="已打乱顺序" data-icon="shuffle">${ic('shuffle')}</button></div>${D.queue.slice(D.queue.indexOf(D.cur) + 1, D.queue.indexOf(D.cur) + 9).map((id, k) => { const x = SONGS[id]; return `<div class="rpq" data-act="play" data-id="${id}" style="--d:${k * 30}ms">${cover(x, 36)}<div><b>${x.t}</b><span>${x.a}</span></div><em>${fmt(x.dur)}</em></div>`; }).join('')}</div></div>
    ${pControls(s)}</div>`;
  const k = Math.max(0, LYRICS.findIndex((l, i) => l.t <= D.pos && (!LYRICS[i + 1] || LYRICS[i + 1].t > D.pos)));
  const shelfItems = { 队列:D.queue.slice(0, 8).map(id => ({ t:SONGS[id].t, s:SONGS[id].a, h:SONGS[id].h, v:SONGS[id].v, n:'' })), 我的歌单:MY.map(x => ({ t:x.t, s:`${x.n} 首`, h:x.h, v:x.v })), 收藏:[...D.liked].map(id => ({ t:SONGS[id].t, s:SONGS[id].a, h:SONGS[id].h, v:SONGS[id].v })), 最近:[D.cur, 5, 11, 2, 16].map(id => ({ t:SONGS[id].t, s:SONGS[id].a, h:SONGS[id].h, v:SONGS[id].v })) }[D.shelfTab];
  return `<div class="player fx ${D.playing ? '' : 'paused'} ${D.idle ? 'idle' : ''}"><canvas class="fxc" data-fx="${D.fxHover || D.fx}"></canvas>${top}
    <div class="fx-lyr"><div class="fl-prev">${LYRICS[k - 1] ? LYRICS[k - 1].o : ''}</div><div class="fl-cur" data-li="${k}"><span class="w">${LYRICS[k].o}</span></div><div class="fl-tr">${D.set.trans ? LYRICS[k].tr : ''}</div><div class="fl-next">${LYRICS[k + 1] ? LYRICS[k + 1].o : ''}</div></div>
    <div class="fx-hud"><span class="beat"></span><b>112 BPM</b><span>${FX_PRESETS.find(p => p.k === (D.fxHover || D.fx)).n}</span><span>${D.set.fxPerf} · 33,489 点</span></div>
    ${D.shelf ? `<div class="shelf"><div class="sh-tabs">${['队列', '我的歌单', '收藏', '最近'].map(t => `<button class="${D.shelfTab === t ? 'on' : ''}" data-act="shelfTab" data-v="${t}">${t}</button>`).join('')}</div>
      <div class="sh-stage">${shelfItems.map((x, i) => { const d = i - D.shelfIdx; if (Math.abs(d) > 3) return ''; return `<div class="sh-card ${d === 0 ? 'on' : ''} ${d === 0 && D.shelfOpen ? 'open' : ''}" style="--d:${d}" data-act="shelfPick" data-i="${i}"><div class="cv" style="${coverStyle(x.h, x.v)}"></div><div class="sh-i"><small>${D.shelfTab}${D.shelfTab === '队列' && i === 0 ? ' · 正在播放' : ''}</small><b>${x.t}</b><span>${x.s}</span>
        ${d === 0 && D.shelfOpen ? `<div class="shelf-l">${SONGS.slice(i, i + 7).map((y, j) => `<div class="sl-r" data-act="play" data-id="${y.id}"><b>${j + 1}</b><span>${y.t}</span><em>${fmt(y.dur)}</em></div>`).join('')}</div>` : ''}</div></div>`; }).join('')}</div>
      <div class="sh-hint">${kbd('滚轮')} 翻页 · 点击展开 · ${kbd('Esc')} 返回</div></div>` : ''}
    <div class="fx-bottom"><div class="fx-strip">${FX_PRESETS.map((p, i) => `<button class="${D.fx === p.k ? 'on' : ''}" data-act="setFx" data-v="${p.k}" data-hover="${p.k}"><canvas class="fxc" data-fx="${p.k}" data-static="1"></canvas><b>${p.n}</b><small>${kbd(String(i + 1))} ${p.c}</small></button>`).join('')}
      ${FX_MORE.slice(0, 6).map(n => `<button class="more" data-act="toast" data-msg="${n}：桌面端完整 26 套预设（原型只演示 4 套）" data-icon="sparkle"><span>${n}</span></button>`).join('')}<button class="more all" data-act="toast" data-msg="打开全部 26 套预设" data-icon="grid">全部 26 套${ic('right')}</button></div>
      ${pControls(s)}</div></div>`;
}
ACT.openPlayer = d => { D.view = d.v || (D.set.fxOn ? 'fx' : 'classic'); closeOverlays(); D._li = -1; render(); };
ACT.closePlayer = () => { D.view = null; D.shelf = false; render(); };
ACT.pvMode = d => { D.view = d.v === '动效' ? 'fx' : 'classic'; D.shelf = false; D._li = -1; render(); };
ACT.setFx = d => { D.fx = d.v; D.fxHover = null; S.particle = d.v; render(); toast(`预设：${FX_PRESETS.find(p => p.k === d.v).n}`, 'sparkle'); };
ACT.tgShelf = () => { D.shelf = !D.shelf; D.shelfOpen = false; render(); };
ACT.shelfTab = (d, e) => { e && e.stopPropagation(); D.shelfTab = d.v; D.shelfIdx = 0; D.shelfOpen = false; render(); };
ACT.shelfPick = (d, e) => { e && e.stopPropagation(); const i = +d.i; if (i === D.shelfIdx) D.shelfOpen = !D.shelfOpen; else { D.shelfIdx = i; D.shelfOpen = false; } render(); };
ACT.goArtist = () => { D.view = null; go('artist', { id:D.cur }); render(); };
ACT.goSetFromPlayer = () => { D.view = null; go('settings'); D.setCat = '动效模式'; render(); };
document.addEventListener('wheel', e => { if (!D.shelf || !e.target.closest('.shelf')) return; e.preventDefault(); const n = { 队列:8, 我的歌单:MY.length, 收藏:D.liked.size, 最近:5 }[D.shelfTab]; D.shelfIdx = Math.max(0, Math.min(n - 1, D.shelfIdx + Math.sign(e.deltaY))); D.shelfOpen = false; render(); }, { passive:false });
document.addEventListener('mouseover', e => { const b = e.target.closest('.fx-strip [data-hover]'); const v = b ? b.dataset.hover : null; if (D.view !== 'fx' || v === D.fxHover) return; D.fxHover = v; const c = document.querySelector('.player.fx > canvas.fxc'); if (c) { c.dataset.fx = v || D.fx; } const hud = document.querySelector('.fx-hud span:nth-child(3)'); if (hud) hud.textContent = FX_PRESETS.find(p => p.k === (v || D.fx)).n; });
function playerTick(k) {
  if (D.view !== 'fx') return;
  const box = document.querySelector('.fx-lyr'); if (!box) return;
  if (+box.dataset.k !== k) { box.dataset.k = k; const L = LYRICS[Math.max(0, k)];
    box.innerHTML = `<div class="fl-prev">${LYRICS[k - 1] ? LYRICS[k - 1].o : ''}</div><div class="fl-cur on" data-li="${k}"><span class="w">${L.o}</span></div><div class="fl-tr">${D.set.trans ? L.tr : ''}</div><div class="fl-next">${LYRICS[k + 1] ? LYRICS[k + 1].o : ''}</div>`; }
}

/* ---------- 迷你模式 ---------- */
function MINI() { const s = song();
  return `<div class="mini-w drag" style="--h:${s.h}"><div class="mw-bg" style="${coverStyle(s.h, s.v)}"></div>${cover(s, 72)}
    <div class="mw-i"><b>${s.t}</b><span>${s.a}</span><div class="mw-l" data-lyr><p class="dl-cur"><span class="w">${LYRICS[Math.max(0, D._li)].o}</span></p></div><div class="mw-pg"><i data-b="mfill"></i></div></div>
    <div class="mw-c nodrag"><button class="ib" data-act="prev">${ic('prev')}</button><button class="mw-play" data-act="toggle">${ic(D.playing ? 'pause' : 'play')}</button><button class="ib" data-act="next">${ic('next')}</button></div>
    <div class="mw-x nodrag"><button class="ib xs" data-act="fromMini" title="还原（双击窗口也可以）">${ic('expand')}</button><button class="ib xs" data-act="toast" data-msg="已置顶" data-icon="up">${ic('up')}</button></div></div>`; }
ACT.toMini = () => { D.mini = true; closeOverlays(); render(); };
ACT.fromMini = (d, e) => { e && e.stopPropagation(); D.mini = false; render(); };

/* ---------- 大屏模式（Exploring） ---------- */
const BANDS = () => [
  ['最近在听', [D.cur, 5, 11, 2, 16, 7, 18, 20, 9, 1].map(id => ({ s:SONGS[id], z:id === D.cur ? 2 : id % 3 === 0 ? 1 : 0 }))],
  ['收藏', [...D.liked, 3, 8, 14, 22, 19, 10].map((id, i) => ({ s:SONGS[id], z:i === 1 ? 2 : i % 4 === 2 ? 1 : 0 }))],
  ['我的歌单', MY.concat(MY).map((x, i) => ({ s:{ ...SONGS[i % 24], t:x.t, a:`${x.n} 首`, h:x.h, v:x.v }, z:i === 0 ? 1 : 0, pl:1 }))],
  ['为你推荐 · 网易云', PLAYLISTS.map((x, i) => ({ s:{ ...SONGS[i], t:x.t, a:x.by, h:x.h, v:x.v }, z:i === 2 ? 2 : i % 3 === 1 ? 1 : 0, pl:1 }))],
  ['新歌', [19, 8, 13, 22, 10, 3, 21, 6, 15, 23].map((id, i) => ({ s:SONGS[id], z:i === 0 ? 1 : 0 }))],
];
function BIG() {
  const s = song(), bands = BANDS(), f = D.bf, k = Math.max(0, D._li);
  return `<div class="big"><canvas class="fxc" data-fx="galaxy"></canvas><div class="big-shade"></div>
    <div class="big-top"><span class="badge acc">EXPLORING · 大屏模式</span><span class="dim">${kbd('←')}${kbd('→')}${kbd('↑')}${kbd('↓')} 移动 · ${kbd('Enter')} 播放 · ${kbd('Esc')} 返回 · ${kbd('M')} 菜单</span><button class="ib" data-act="fromBig">${ic('close')}</button></div>
    <div class="big-col"><div class="cv" style="${coverStyle(s.h, s.v)}"></div><small>正在播放</small><h1>${s.t}</h1><p>${s.a} · ${pb(platBy(pidOf(s.id)), 20)}</p>
      <div class="bc-l"><span>${LYRICS[Math.max(0, k - 1)].o}</span><b>${LYRICS[k].o}</b><span>${LYRICS[k + 1] ? LYRICS[k + 1].o : ''}</span></div><div class="bc-pg"><i data-b="mfill"></i></div></div>
    <div class="big-vp"><div class="big-wall" style="--by:${f.b}">${bands.map(([t, items], b) => `<div class="band ${b === f.b ? 'on' : ''}" style="--bx:${b === f.b ? f.i : 0}"><h2>${t}</h2><div class="b-row">${items.map((x, i) => `<div class="bcard z${x.z} ${b === f.b && i === f.i ? 'focus' : ''}" data-act="bigPick" data-b="${b}" data-i="${i}"><div class="cv" style="${coverStyle(x.s.h, x.s.v)}"></div>${pb(platBy(pidOf(x.s.id)), 26)}<div class="bci"><b>${x.s.t}</b><span>${x.s.a}</span></div>${b === f.b && i === f.i ? '<i class="bc-try">停留 1.2 秒自动试听</i>' : ''}</div>`).join('')}</div></div>`).join('')}</div></div></div>`;
}
ACT.toBig = () => { D.big = true; D.view = null; closeOverlays(); D.bf = { b:0, i:0 }; render(); };
ACT.fromBig = () => { D.big = false; render(); };
ACT.bigPick = d => { const b = +d.b, i = +d.i; if (D.bf.b === b && D.bf.i === i) { const x = BANDS()[b][1][i]; if (!x.pl) playSong(x.s.id); toast(x.pl ? `打开「${x.s.t}」` : `播放「${x.s.t}」`, 'play'); } D.bf = { b, i }; render(); };
function bigKey(e) {
  const bands = BANDS(), f = D.bf;
  if (e.key === 'ArrowRight') f.i = Math.min(bands[f.b][1].length - 1, f.i + 1);
  else if (e.key === 'ArrowLeft') f.i = Math.max(0, f.i - 1);
  else if (e.key === 'ArrowDown') { f.b = Math.min(bands.length - 1, f.b + 1); f.i = Math.min(f.i, bands[f.b][1].length - 1); }
  else if (e.key === 'ArrowUp') { f.b = Math.max(0, f.b - 1); f.i = Math.min(f.i, bands[f.b][1].length - 1); }
  else if (e.key === 'Enter') { ACT.bigPick({ b:f.b, i:f.i }); return; }
  else if (e.key.toLowerCase() === 'm') { toast('菜单：播放模式 / 动效模式 / 退出大屏', 'more'); return; }
  else return;
  e.preventDefault(); render();
}
