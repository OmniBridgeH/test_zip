/* Lyra 桌面端原型 · 核心：状态、窗口外壳、路由、动作、事件、播放计时。
   对应 Electron 实现：D ≈ Pinia/Vuex store；PAGES ≈ vue-router 路由；render() ≈ 响应式重绘。 */
ICONS.video = '<rect x="3" y="5.5" width="13" height="13" rx="2.5"/><path d="m16 10 5-3v10l-5-3z"/>';
ICONS.trend = '<path d="M3 17l6-6 4 4 8-8"/><path d="M15 7h6v6"/>';
ICONS.music = '<circle cx="7" cy="17" r="3"/><circle cx="17" cy="15" r="3"/><path d="M10 17V5l10-2v12"/>';
ICONS.min = '<path d="M5 12h14"/>'; ICONS.max = '<rect x="5" y="5" width="14" height="14" rx="1.5"/>';
ICONS.restore = '<rect x="5" y="8" width="11" height="11" rx="1.5"/><path d="M8 8V5h11v11h-3"/>';
ICONS.sidebar = '<rect x="3" y="4" width="18" height="16" rx="2.5"/><path d="M9 4v16"/>';
ICONS.panel = '<rect x="3" y="4" width="18" height="16" rx="2.5"/><path d="M15 4v16"/>';
ICONS.pip = '<rect x="3" y="5" width="18" height="14" rx="2.5"/><rect x="12" y="11" width="7" height="6" rx="1.2" fill="currentColor"/>';
ICONS.expand = '<path d="M14 4h6v6M10 20H4v-6M20 4l-7 7M4 20l7-7"/>';
ICONS.cmd = '<path d="M9 6a3 3 0 1 0-3 3h12a3 3 0 1 0-3-3v12a3 3 0 1 0 3-3H6a3 3 0 1 0 3 3z"/>';
ICONS.tray = '<path d="M4 15h4l2 3h4l2-3h4"/><path d="M4 15V6a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v9"/>';
ICONS.sparkles = ICONS.sparkle;

PLATFORMS.splice(3);                                    // 本期只做 网易云 / QQ / 酷狗
SCRIPTS.forEach(s => { s.p = s.p.filter(p => ['netease', 'qq', 'kugou'].includes(p)); });
const PL3 = PLATFORMS;
const pidOf = id => PL3[id % 3].id;
const platBy = id => PL3.find(p => p.id === id);

const D = {
  theme:'dark', accent:0, route:{ p:'discover', a:{} }, back:[], fwd:[],
  sb:false, rp:'queue', rpOpen:true, plat:'netease', script:'auto', login:{ netease:'小栗子' }, picker:false,
  playing:true, cur:0, pos:31, vol:.72, muted:false, mode:'loop', liked:new Set([0, 4, 7, 12, 17]), quality:'SQ',
  queue:SONGS.slice(0, 18).map(s => s.id), sel:new Set(), anchor:null, sort:{ k:null, dir:1 },
  ctx:null, pal:false, q:'', sType:'单曲', sPlat:'all', pIdx:0,
  view:null, fx:'galaxy', fxHover:null, shelf:false, shelfTab:'队列', shelfIdx:0, shelfOpen:false, idle:false,
  mini:false, deskLyric:false, deskLock:false, dlg:null, pop:null, toastT:0, big:false, bf:{ b:0, i:0 },
  homeTab:'精选', sqTag:'全部', sqSort:'推荐', sqOpen:false, localView:'歌曲', statRange:'近 30 天', smartSel:0,
  setCat:'通用', setQ:'', rec:null, maximized:false, sync:'ok', libSort:'自定义', dupes:false, editTag:null,
  set:{ theme:'dark', animation:true, closeAction:'ask', uiFontSize:'默认', taskbarProgress:true, quality:'flac', fade:false, fadeIn:300, fadeOut:200,
    autoSkip:true, loudness:'off', preamp:0, preventClip:true, rate:1, pitch:true, lfs:44, lfw:700, lgap:16, lop:.25, lblur:true, lalign:'left', trans:true, roma:false,
    dlFs:34, dlTop:true, dlHoverHide:false, dlTaskbar:false, dlStroke:true, fxOn:true, fxPerf:'高', fxShield:true, fxBloom:true, fxAuto:true, hkLocal:true, hkGlobal:false,
    builtin:false, smart:true, cacheMb:2048, dlConc:3, dlCover:true, dlLyric:true, cloud:true, autoBackup:true, checkUpd:true, checkSrc:true, server:'https://api.example.com/api/v1', eq:[0, 1, 3, 4, 3, 0, -1, -1, 1, 2], spatial:false, reverb:'无' },
  hk:{ togglePlay:'Ctrl+F5', previous:'Ctrl+←', next:'Ctrl+→', focusSearch:'F1', gTogglePlay:'Ctrl+Alt+F5', gPrev:'Ctrl+Alt+←', gNext:'Ctrl+Alt+→', gVolUp:'Ctrl+Alt+↑', gVolDown:'Ctrl+Alt+↓', gLyric:'Ctrl+Alt+0', gLock:'Ctrl+Alt+-', gTop:'Ctrl+Alt+=', seekB:'', seekF:'', mute:'', fav:'' },
};
var S = D;                                              // fx.js 兼容：它读取 S.pos / S.playing / S.accent
S.particle = 'galaxy';
const song = () => SONGS[D.cur];
const isIn = p => !!D.login[p];
const plat = () => platBy(D.plat);
const scriptsOf = pid => SCRIPTS.filter(s => s.p.includes(pid));
const curScript = () => D.script === 'auto' ? { n:'自动选择', ms:scriptsOf(D.plat)[0]?.ms || 0, ok:99 } : SCRIPTS.find(s => s.id === D.script);
const MY = [{ id:100, t:'我喜欢的音乐', n:128, h:42, v:0, ic:'heartf' }, { id:101, t:'开车专用', n:46, h:12, v:3 }, { id:102, t:'睡前十首', n:10, h:230, v:1 }, { id:103, t:'从桌面端导入 · 收藏夹', n:213, h:265, v:2 }, { id:104, t:'雨天 Lo-fi', n:31, h:280, v:0 }];
const SMART = [{ id:200, t:'最近常听的无损', n:42, rules:[['pool', '收藏与最近播放'], ['q', '无损及以上'], ['play', '播放次数', '大于', '5']] }, { id:201, t:'冷门宝藏', n:25, rules:[['pool', '本地音乐'], ['play', '播放次数', '小于', '2']] }];

/* ================= 小组件 ================= */
const cover = (s, size, cls = '') => `<div class="cv ${cls}" style="${coverStyle(s.h, s.v)}${size ? `;width:${size}px;height:${size}px` : ''}"></div>`;
const pb = (p, size = 16) => `<span class="pb" style="width:${size}px;height:${size}px;font-size:${Math.round(size * .55)}px;background:linear-gradient(140deg,${p.c},${p.c2})">${p.m}</span>`;
const sig = ms => { const n = ms < 400 ? 4 : ms < 700 ? 3 : ms < 1000 ? 2 : 1; return `<span class="sig s${n}">${[1, 2, 3, 4].map(i => `<i class="${i <= n ? 'on' : ''}"></i>`).join('')}</span>`; };
const qb = q => `<b class="qb ${q === 'HQ' || q === '128k' ? 'plain' : ''}">${q}</b>`;
const kbd = k => k ? k.split('+').map(x => `<kbd>${x}</kbd>`).join('') : '<span class="dim">未设置</span>';
const seg = (opts, cur, act, cls = '') => `<div class="seg ${cls}" style="--n:${opts.length};--i:${Math.max(0, opts.indexOf(cur))}"><i></i>${opts.map(o => `<button class="${o === cur ? 'on' : ''}" data-act="${act}" data-v="${o}">${o}</button>`).join('')}</div>`;
const sw = (k, on) => `<button class="sw ${on ? 'on' : ''}" data-act="tgSet" data-k="${k}"></button>`;
const empty = (icon, t, d, btn = '') => `<div class="empty">${ic(icon)}<b>${t}</b><p>${d}</p>${btn}</div>`;
function songTable(ids, o = {}) {
  let rows = ids.map(id => SONGS[id]);
  if (D.sort.k && o.sortable !== false) { const k = D.sort.k; rows = rows.slice().sort((a, b) => (k === 'dur' ? a.dur - b.dur : String(a[k]).localeCompare(String(b[k]), 'zh')) * D.sort.dir); }
  const col = (k, n, cls = '') => `<div class="th ${cls} ${D.sort.k === k ? 'sorted' : ''}" ${o.sortable === false ? '' : `data-act="sortBy" data-v="${k}"`}>${n}${D.sort.k === k ? ic(D.sort.dir > 0 ? 'up' : 'down') : ''}</div>`;
  return `<div class="tbl ${o.cls || ''}" data-list="${o.list || 'all'}">
    <div class="tr th-row">${col('', '#', 'c-no')}${col('t', '标题', 'c-t')}${col('al', '专辑', 'c-al')}${col('plat', '来源', 'c-pl')}${col('q', '音质', 'c-q')}${o.extra ? `<div class="th c-x">${o.extra[0]}</div>` : ''}${col('dur', '时长', 'c-d')}<div class="th c-op"></div></div>
    ${rows.map((s, i) => { const p = platBy(pidOf(s.id)), cur = s.id === D.cur, sel = D.sel.has(s.id), grey = o.grey && o.grey(s);
      return `<div class="tr ${cur ? 'cur' : ''} ${sel ? 'sel' : ''} ${grey ? 'grey' : ''}" data-row="${s.id}" draggable="true" data-ctx="song" data-id="${s.id}" style="--d:${Math.min(i, 14) * 18}ms">
        <div class="c-no">${cur ? `<span class="eqm ${D.playing ? '' : 'p'}"><i></i><i></i><i></i></span>` : `<span class="n">${o.nums ? o.nums[i] : String(i + 1).padStart(2, '0')}</span>`}<button class="rp-play" data-act="play" data-id="${s.id}">${ic('play')}</button></div>
        <div class="c-t">${cover(s, 36)}<div><b>${o.hl ? o.hl(s.t) : s.t}${grey ? '<em class="tag-grey">无版权</em>' : ''}</b><span>${o.hl ? o.hl(s.a) : s.a}</span></div></div>
        <div class="c-al">${s.al}</div><div class="c-pl">${pb(p)}<span>${p.n.replace('音乐', '')}</span></div><div class="c-q">${qb(s.q)}</div>
        ${o.extra ? `<div class="c-x">${o.extra[1](s, i)}</div>` : ''}
        <div class="c-d">${fmt(s.dur)}</div>
        <div class="c-op"><button class="heart ${D.liked.has(s.id) ? 'on' : ''}" data-act="like" data-id="${s.id}">${ic(D.liked.has(s.id) ? 'heartf' : 'heart')}</button><button data-act="ctxBtn" data-id="${s.id}">${ic('more')}</button></div></div>`; }).join('')}</div>`;
}
const card = (x, o = {}) => `<div class="card-pl" data-act="${o.act || 'go'}" data-v="${o.v || 'collection'}" data-id="${x.id}" data-ctx="playlist" style="--d:${(o.i || 0) * 30}ms">
  <div class="cp-cv">${o.cv || `<div class="cv" style="${coverStyle(x.h, x.v)}"></div>`}<button class="cp-play" data-act="playAll" data-list="all">${ic('play')}</button>${x.pc ? `<span class="cp-pc">${ic('play')}${x.pc}</span>` : ''}</div>
  <b>${x.t}</b><span>${o.sub || `${x.n} 首${x.by ? ' · ' + x.by : ''}`}${o.plat ? pb(platBy(o.plat), 14) : ''}</span></div>`;
const secH = (t, more, act = '') => `<div class="sec-h"><h2>${t}</h2>${more ? `<button class="more" ${act}>${more}${ic('right')}</button>` : ''}</div>`;

/* ================= 窗口外壳 ================= */
function titlebar() {
  const p = plat(), sc = curScript();
  return `<header class="tb drag">
    <div class="tb-l nodrag"><button class="ib ${D.sb ? 'acc' : ''}" data-act="tgSb" title="${D.sb ? '展开' : '收起'}侧边栏 Ctrl+B">${ic('sidebar')}</button>
      <button class="ib ${D.back.length ? '' : 'dis'}" data-act="nav" data-v="-1">${ic('left')}</button><button class="ib ${D.fwd.length ? '' : 'dis'}" data-act="nav" data-v="1">${ic('right')}</button></div>
    <div class="tb-search nodrag ${D.pal ? 'open' : ''}" data-act="palOpen">${ic('search')}<input id="q" placeholder="搜索歌曲、歌手、歌单，或输入命令" value="${D.q}" autocomplete="off"><span class="kb">${kbd('Ctrl+K')}</span></div>
    <button class="tb-src nodrag ${D.picker ? 'open' : ''}" data-act="picker">${pb(p, 20)}<b>${p.n}</b><i></i>${sig(sc.ms)}<span>${sc.n}</span>${ic('down')}</button>
    <div class="tb-r nodrag">
      <button class="ib sync s-${D.sync}" data-act="pop" data-v="sync" title="云同步">${ic('cloud')}<i></i></button>
      <button class="ib" data-act="go" data-v="settings" title="设置">${ic('gear')}</button>
      <button class="tb-av" data-act="pop" data-v="user"><span class="avatar">栗</span></button>
      <span class="tb-sep"></span>
      <button class="wc" data-act="toMini" title="迷你模式">${ic('pip')}</button>
      <button class="wc" data-act="toast" data-msg="已最小化（原型）" data-icon="min">${ic('min')}</button>
      <button class="wc" data-act="tgMax">${ic(D.maximized ? 'restore' : 'max')}</button>
      <button class="wc x" data-act="close">${ic('close')}</button></div></header>`;
}
const NAV = [
  ['发现', [['discover', 'compass', '推荐'], ['charts', 'chart', '排行榜'], ['square', 'grid', '歌单广场']]],
  ['我的', [['favorites', 'heart', '收藏'], ['local', 'folder', '本地音乐'], ['history', 'history', '最近播放'], ['stats', 'trend', '听歌统计']]],
];
function sidebar() {
  const on = k => D.route.p === k || (k === 'collection' && 0);
  const it = (k, i, n, extra = '') => `<button class="sb-it ${on(k) ? 'on' : ''}" data-act="go" data-v="${k}" title="${n}">${ic(i)}<span>${n}</span>${extra}</button>`;
  return `<aside class="sb ${D.sb ? 'mini' : ''}">
    <div class="sb-brand drag"><div class="brand-ic"></div><b>Lyra</b><button class="ib nodrag" data-act="tgSb" title="收起侧边栏">${ic('sidebar')}</button></div>
    <div class="sb-scroll">
      ${NAV.map(([g, items]) => `<div class="sb-g">${g}</div>${items.map(x => it(...x)).join('')}`).join('')}
      <div class="sb-g">歌单<span><button data-act="dlg" data-v="importPl" title="导入歌单">${ic('download')}</button><button data-act="dlg" data-v="newPl" title="新建歌单">${ic('plus')}</button></span></div>
      ${SMART.map(x => `<button class="sb-it pl ${D.route.p === 'smart' && D.smartSel === SMART.indexOf(x) ? 'on' : ''}" data-act="goSmart" data-i="${SMART.indexOf(x)}" data-drop="${x.id}">${ic('sparkle')}<span>${x.t}</span><em>${x.n}</em></button>`).join('')}
      ${MY.map(x => `<button class="sb-it pl ${D.route.p === 'collection' && D.route.a.id === x.id ? 'on' : ''}" data-act="go" data-v="collection" data-id="${x.id}" data-drop="${x.id}" data-ctx="myPl">${x.ic ? `<span class="pl-ic like">${ic('heartf')}</span>` : `<span class="pl-ic" style="${coverStyle(x.h, x.v)}"></span>`}<span>${x.t}</span><em>${x.n}</em></button>`).join('')}
    </div>
    <div class="sb-foot">${it('sources', 'layers', '平台与解析脚本')}</div></aside>`;
}
function playerBar() {
  const s = song(), p = platBy(pidOf(s.id)), pr = s.dur ? D.pos / s.dur : 0;
  return `<footer class="pbar">
    <div class="pb-l"><button class="pb-cv" data-act="openPlayer" data-v="classic">${cover(s, 56)}<span class="pb-ex">${ic('up')}</span></button>
      <div class="pb-ti"><b>${s.t}</b><span>${s.a} · ${pb(p, 14)} ${p.n.replace('音乐', '')}</span></div>
      <button class="heart ${D.liked.has(s.id) ? 'on' : ''}" data-act="like" data-id="${s.id}">${ic(D.liked.has(s.id) ? 'heartf' : 'heart')}</button></div>
    <div class="pb-c">
      <div class="pb-btns"><button class="ib ${D.mode === 'shuffle' ? 'acc' : ''}" data-act="mode" title="播放模式">${ic({ loop:'repeat', one:'repeat1', shuffle:'shuffle', order:'order' }[D.mode])}</button>
        <button class="ib" data-act="prev">${ic('prev')}</button><button class="pb-play" data-act="toggle">${ic(D.playing ? 'pause' : 'play')}</button><button class="ib" data-act="next">${ic('next')}</button>
        <button class="ib" data-act="openPlayer" data-v="fx" title="动效模式">${ic('sparkle')}</button></div>
      <div class="pb-prog"><span data-b="pos">${fmt(D.pos)}</span><div class="prog" data-seek="song"><i class="buf"></i><i class="fill" data-b="fill" style="width:${pr * 100}%"></i><b class="th" data-b="thumb" style="left:${pr * 100}%"></b></div><span>${fmt(s.dur)}</span></div></div>
    <div class="pb-r"><button class="qchip" data-act="pop" data-v="quality">${D.quality}</button>
      <button class="ib ${D.rpOpen && D.rp === 'lyrics' ? 'acc' : ''}" data-act="rp" data-v="lyrics" title="歌词">${ic('quote')}</button>
      <button class="ib ${D.deskLyric ? 'acc' : ''}" data-act="tgDeskLyric" title="桌面歌词 Ctrl+Alt+0">${ic('lyric')}</button>
      <button class="ib" data-act="pop" data-v="output" title="输出设备">${ic('volume')}</button>
      <div class="vol"><div class="prog sm" data-seek="vol"><i class="fill" style="width:${D.vol * 100}%"></i><b class="th" style="left:${D.vol * 100}%"></b></div></div>
      <button class="ib ${D.rpOpen && D.rp === 'queue' ? 'acc' : ''}" data-act="rp" data-v="queue" title="播放队列">${ic('queue')}</button></div>
    <div class="pb-glow" style="--h:${s.h}"></div></footer>`;
}
function rightPanel() {
  if (!D.rpOpen) return '';
  const tabs = [['queue', '队列'], ['lyrics', '歌词'], ['similar', '相似'], ...(D.dupes ? [['dupes', '重复项']] : []), ...(D.editTag != null ? [['tag', '标签']] : [])];
  return `<aside class="rp"><div class="rp-tabs">${tabs.map(([k, n]) => `<button class="${D.rp === k ? 'on' : ''}" data-act="rp" data-v="${k}">${n}</button>`).join('')}<button class="ib" data-act="rpClose">${ic('close')}</button></div>
    <div class="rp-body" key="${D.rp}">${RP[D.rp] ? RP[D.rp]() : ''}</div></aside>`;
}
const RP = {
  queue:() => { const i = D.queue.indexOf(D.cur), next = D.queue.slice(i + 1).concat(D.queue.slice(0, i));
    return `<div class="rpq-now">${cover(song(), 52)}<div><small>正在播放</small><b>${song().t}</b><span>${song().a}</span></div></div>
      <div class="rp-h"><b>接下来 · ${next.length}</b><button data-act="toast" data-msg="已清空队列" data-icon="trash">清空</button></div>
      ${next.map((id, k) => { const s = SONGS[id]; return `<div class="rpq" data-act="play" data-id="${id}" draggable="true" data-row="${id}" data-ctx="song" data-id="${id}" style="--d:${Math.min(k, 12) * 20}ms">${cover(s, 36)}<div><b>${s.t}</b><span>${s.a}</span></div><em>${fmt(s.dur)}</em><i class="drag-h">${ic('drag')}</i></div>`; }).join('')}`; },
  lyrics:() => `<div class="rpl" data-lyr>${LYRICS.map((l, i) => `<p data-li="${i}" data-act="seekLine" data-i="${i}">${l.o}${D.set.trans ? `<small>${l.tr}</small>` : ''}</p>`).join('')}</div>`,
  similar:() => `<div class="rp-h"><b>和「${song().t}」相似</b></div>${[5, 9, 14, 20, 2, 18, 11].map(id => { const s = SONGS[id]; return `<div class="rpq" data-act="play" data-id="${id}" data-ctx="song">${cover(s, 36)}<div><b>${s.t}</b><span>${s.a} · 相似度 ${90 - id}%</span></div>${pb(platBy(pidOf(id)), 14)}</div>`; }).join('')}`,
  dupes:() => `<div class="rp-h"><b>找到 3 组重复</b><button data-act="toast" data-msg="已保留最高音质版本，移除 3 首" data-icon="check">一键保留最佳</button></div>
    ${[[0, 13], [4, 15], [7, 21]].map(([a, b]) => `<div class="dupe">${[a, b].map((id, k) => { const s = SONGS[id]; return `<label class="dp-r ${k ? '' : 'best'}"><input type="radio" name="d${a}" ${k ? '' : 'checked'}>${cover(SONGS[a], 34)}<div><b>${SONGS[a].t}</b><span>${pb(PL3[k + (a % 2)], 14)} ${k ? 'HQ · 加入于 2025.12' : 'SQ · 加入于 2026.03'}</span></div>${k ? '' : '<em>推荐保留</em>'}</label>`; }).join('')}</div>`).join('')}`,
  tag:() => { const s = SONGS[D.editTag || 0]; return `<div class="tag-ed"><div class="te-cv">${cover(s, 180)}<button data-act="toast" data-msg="选择封面图片" data-icon="album">${ic('edit')}更换封面</button></div>
    ${[['标题', s.t], ['艺术家', s.a], ['专辑', s.al], ['年份', '2026'], ['流派', '城市流行'], ['音轨号', '3 / 10']].map(([k, v]) => `<label class="fld-d"><span>${k}</span><input value="${v}"></label>`).join('')}
    <p class="hint">文件：D:\\Music\\${s.a} - ${s.t}.flac · FLAC 24bit/96kHz · 38.2 MB</p>
    <div class="row-btns"><button class="btn sec" data-act="rp" data-v="queue">取消</button><button class="btn pri" data-act="toast" data-msg="已写入文件标签" data-icon="check">保存到文件</button></div></div>`; },
};

/* ================= 渲染 ================= */
const scrollKeep = {};
function render() {
  const win = document.getElementById('win');
  ['.content', '.rp-body', '.set-body', '.shelf-l'].forEach(s => { const el = win.querySelector(s); if (el) scrollKeep[s + (s === '.content' ? D.route.p : '')] = el.scrollTop; });
  document.documentElement.dataset.theme = D.theme;
  win.className = `win ${D.maximized ? 'max' : ''} ${D.mini ? 'mini' : ''} ${D.big ? 'bigmode' : ''}`;
  if (D.mini) win.innerHTML = MINI();
  else if (D.big) win.innerHTML = BIG();
  else {
    const P = PAGES[D.route.p] || PAGES.notfound;
    win.innerHTML = `${titlebar()}<div class="body">${sidebar()}<main class="content ${P.full ? 'full' : ''}" data-page="${D.route.p}">${P.render(D.route.a)}</main>${P.full ? '' : rightPanel()}</div>${playerBar()}
      ${D.view ? PLAYER() : ''}${D.picker ? picker() : ''}${D.pal ? palette() : ''}${D.pop ? popover() : ''}${D.ctx ? ctxMenu() : ''}${D.dlg ? dialog() : ''}`;
  }
  ['.content', '.rp-body', '.set-body', '.shelf-l'].forEach(s => { const el = win.querySelector(s); const k = s + (s === '.content' ? D.route.p : ''); if (el && scrollKeep[k]) el.scrollTop = scrollKeep[k]; });
  document.getElementById('desklyric').style.display = D.deskLyric ? '' : 'none';
  const dlw = document.getElementById('desklyric'); dlw.classList.toggle('locked', D.deskLock);
  dlw.querySelector('.dl-bar').innerHTML = [['prev', 'prev', '上一首'], ['toggle', D.playing ? 'pause' : 'play', '播放/暂停'], ['next', 'next', '下一首'], ['font', 'font', '字号'], ['lock', 'lock', '锁定（鼠标穿透）'], ['close', 'close', '关闭桌面歌词']].map(([a, i, t]) => `<button data-dl="${a}" title="${t}">${ic(i)}</button>`).join('') + `<button class="dl-unlock" data-dl="lock" title="解锁桌面歌词">${ic('unlock')}</button>`;
  applyAccent();
  const q = win.querySelector('#q'); if (q && D._focusQ) { q.focus(); q.setSelectionRange(q.value.length, q.value.length); D._focusQ = false; }
  if (typeof mountFx === 'function') mountFx(win);
  afterRender(win);
  if (D._li >= 0) lyricLayout(D._li); // 重绘后立即恢复歌词定位，避免当前行丢失
  if (typeof syncDir === 'function') syncDir();
}
function afterRender(win) {
  const c = win.querySelector('.content');
  if (c) { c.onscroll = () => { c.style.setProperty('--sy', Math.min(240, c.scrollTop)); }; c.style.setProperty('--sy', Math.min(240, c.scrollTop)); }
  if (D._stag) { win.querySelectorAll('.content .tr, .content .card-pl, .content .sec-h, .content .blk').forEach(el => el.classList.add('in')); D._stag = false; }
}
function applyAccent() {
  const a = ACCENTS[D.accent], st = document.documentElement.style, rgb = a.c.match(/\w\w/g).map(x => parseInt(x, 16));
  st.setProperty('--accent', a.c); st.setProperty('--accent-text', D.theme === 'light' ? a.lt : a.c); st.setProperty('--accent-ink', a.ink);
  st.setProperty('--accent-soft', `rgba(${rgb},${D.theme === 'light' ? .14 : .13})`); st.setProperty('--accent-glow', `rgba(${rgb},.36)`);
}
let toastTimer;
function toast(msg, icon = 'check') {
  const t = document.getElementById('toast'); t.innerHTML = `<span class="ti">${ic(icon)}</span>${msg}`;
  t.classList.remove('show'); void t.offsetWidth; t.classList.add('show'); clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.remove('show'), 2000);
}

/* ================= 弹层：平台选择器 / 命令面板 / 弹出卡 / 右键菜单 / 对话框 ================= */
function picker() {
  const list = scriptsOf(D.plat).sort((a, b) => b.ok - a.ok);
  return `<div class="ov" data-act="closeOv"></div><div class="pk">
    <div class="pk-h">音乐平台<small>决定发现、排行榜、歌单广场的数据来源</small></div>
    <div class="pk-ps">${PL3.map(p => `<button class="${p.id === D.plat ? 'on' : ''}" data-act="setPlat" data-v="${p.id}">${pb(p, 40)}<b>${p.n}</b><small class="${isIn(p.id) ? 'in' : ''}">${isIn(p.id) ? '已登录 · ' + D.login[p.id] : '未登录'}</small></button>`).join('')}</div>
    <div class="pk-h">解析脚本<small>${plat().n} 可用 ${list.length} 个 · 按成功率排序</small></div>
    <div class="pk-l" key="${D.plat}"><button class="${D.script === 'auto' ? 'on' : ''}" data-act="setScript" data-v="auto">${ic('zap')}<div><b>自动选择 <em class="badge acc">推荐</em></b><small>失败时按智能换源规则依次切换</small></div>${ic('check')}</button>
      ${list.map((s, i) => `<button class="${D.script === s.id ? 'on' : ''}" data-act="setScript" data-v="${s.id}" style="--d:${(i + 1) * 40}ms">${ic('code')}<div><b>${s.n} <em>v${s.v}</em></b><small>${s.q.map(qb).join(' ')} · 成功率 ${s.ok}%</small></div>${sig(s.ms)}<span class="ms">${s.ms}ms</span>${ic('check')}</button>`).join('')}</div>
    <div class="pk-f"><button data-act="go" data-v="sources">${ic('grid')}管理平台与脚本</button><button data-act="goSet" data-v="播放与音质">${ic('zap')}智能换源</button></div></div>`;
}
const COMMANDS = [
  ['切换深色 / 浅色主题', 'sun', 'tgTheme'], ['打开动效模式', 'sparkle', 'openPlayer', 'fx'], ['打开设置 · 快捷键', 'gear', 'goSet', '快捷键'], ['进入大屏模式（探索）', 'tv', 'toBig'],
  ['迷你模式', 'pip', 'toMini'], ['显示 / 隐藏桌面歌词', 'lyric', 'tgDeskLyric'], ['新建歌单', 'plus', 'dlg', 'newPl'], ['导入歌单', 'download', 'dlg', 'importPl'], ['睡眠定时 30 分钟', 'moon', 'toast', ''],
];
function palette() {
  const q = D.q.trim(), ql = q.toLowerCase();
  let items = [];
  if (q) {
    items.push({ g:'搜索', i:'search', t:`搜索「${q}」`, s:'全部平台 · 回车', act:'doSearch' });
    SONGS.filter(s => (s.t + s.a).toLowerCase().includes(ql)).slice(0, 4).forEach(s => items.push({ g:'歌曲', i:'music', t:s.t, s:s.a, act:'play', id:s.id, cv:s }));
    [...new Set(SONGS.map(s => s.a))].filter(a => a.toLowerCase().includes(ql)).slice(0, 2).forEach(a => items.push({ g:'歌手', i:'user', t:a, s:'歌手', act:'go', v:'artist', id:SONGS.find(s => s.a === a).id }));
    const cmds = COMMANDS.filter(c => c[0].toLowerCase().includes(ql)).map(c => ({ g:'命令', i:c[1], t:c[0], act:c[2], v:c[3] }));
    items = cmds.length ? [...cmds, ...items] : items; // 命中命令时命令优先，回车直接执行
  } else {
    ['夜航星图', '雾港', 'Lo-fi', '后摇'].forEach(h => items.push({ g:'最近搜索', i:'history', t:h, act:'sq', q:h }));
    HOT.slice(0, 4).forEach((h, k) => items.push({ g:'热搜', i:'flame', t:h, s:`#${k + 1}`, act:'sq', q:h }));
    COMMANDS.slice(0, 5).forEach(c => items.push({ g:'命令', i:c[1], t:c[0], act:c[2], v:c[3] }));
  }
  D._palItems = items; const idx = Math.min(D.pIdx, items.length - 1);
  let g = '';
  return `<div class="ov clear" data-act="closeOv"></div><div class="pal">${items.map((x, i) => { const h = x.g !== g ? `<div class="pal-g">${x.g}</div>` : ''; g = x.g;
    return `${h}<button class="pal-it ${i === idx ? 'on' : ''}" data-act="${x.act}" data-v="${x.v || ''}" data-id="${x.id ?? ''}" data-q="${x.q || ''}" data-msg="${x.t}" data-pi="${i}">${x.cv ? cover(x.cv, 28) : `<span class="pi">${ic(x.i)}</span>`}<b>${q ? x.t.replace(q, `<em>${q}</em>`) : x.t}</b>${x.s ? `<small>${x.s}</small>` : ''}${i === idx ? '<kbd>↵</kbd>' : ''}</button>`; }).join('')}
    <div class="pal-f"><span>${kbd('↑')}${kbd('↓')} 选择</span><span>${kbd('↵')} 确认</span><span>${kbd('Esc')} 关闭</span><span class="r">输入 <kbd>&gt;</kbd> 只看命令</span></div></div>`;
}
function popover() {
  const p = D.pop;
  const body = {
    user:() => `<div class="pop-user"><span class="avatar lg">栗</span><div><b>阿栗</b><small>UID 10086427 · ali@example.com</small><span class="badge acc">${ic('crown')}赞助者 · 永久</span></div></div>
      <div class="pop-stats">${[['128', '收藏'], ['12', '歌单'], ['96h', '聆听']].map(([v, n]) => `<div><b>${v}</b><small>${n}</small></div>`).join('')}</div>
      <div class="pop-plats">${PL3.map(x => `<div>${pb(x, 22)}<span>${x.n}</span><button class="btn ${isIn(x.id) ? 'sec' : 'pri'} xs" data-act="${isIn(x.id) ? 'logoutPlat' : 'dlg'}" data-v="${isIn(x.id) ? x.id : 'platLogin'}" data-p="${x.id}">${isIn(x.id) ? '退出' : '登录'}</button></div>`).join('')}</div>
      <div class="pop-menu"><button data-act="go" data-v="stats">${ic('trend')}听歌统计</button><button data-act="goSet" data-v="通用">${ic('gear')}设置</button><button data-act="toast" data-msg="资料编辑" data-icon="edit">${ic('edit')}编辑资料</button><button class="dz" data-act="toast" data-msg="已退出登录（原型）" data-icon="logout">${ic('logout')}退出登录</button></div>`,
    sync:() => `<div class="pop-h">${ic('cloud')}<b>云同步</b>${sw('cloud', D.set.cloud)}</div>
      ${D.sync === 'conflict' ? `<div class="banner warn">${ic('info')}<div><b>本地和云端都有改动</b><small>「开车专用」歌单在两台设备上都被修改</small></div></div><div class="row-btns"><button class="btn sec sm" data-act="syncFix">保留本地</button><button class="btn pri sm" data-act="syncFix">使用云端</button></div>`
      : `<div class="sync-st s-${D.sync}"><i></i><div><b>${D.sync === 'busy' ? '正在同步…' : D.sync === 'err' ? '同步失败' : '已同步'}</b><small>${D.sync === 'err' ? '网络连接超时 · 2 分钟前' : '收藏 128 · 歌单 12 · 刚刚'}</small></div><button class="btn sec sm" data-act="syncNow">${D.sync === 'err' ? '重试' : '立即同步'}</button></div>`}
      <div class="pop-g">备份</div>${['今天 09:12 · 1.2 MB', '昨天 21:40 · 1.2 MB', '11 月 1 日 · 1.1 MB'].map(x => `<div class="pop-row">${ic('history')}<span>${x}</span><button data-act="dlg" data-v="restore">恢复</button></div>`).join('')}
      <div class="pop-menu"><button data-act="toast" data-msg="已上传当前数据为备份" data-icon="cloud">${ic('cloud')}上传当前数据为备份</button><button data-act="syncDemo">${ic('info')}演示：冲突状态</button></div>`,
    quality:() => `<div class="pop-h"><b>音质</b><small>当前歌曲最高 ${song().q}</small></div>${[['128k', '标准', '128kbps'], ['HQ', '较高', '320kbps'], ['SQ', '无损', 'FLAC 16bit'], ['Hi-Res', '高解析', 'FLAC 24bit']].map(([k, n, d]) => `<button class="pop-q ${D.quality === k ? 'on' : ''}" data-act="setQ" data-v="${k}"><b>${n}</b>${qb(k)}<small>${d}</small>${ic('check')}</button>`).join('')}`,
    output:() => `<div class="pop-h"><b>输出设备</b></div>${['扬声器 (Realtek High Definition Audio)', '耳机 (Sony WH-1000XM6)', 'HDMI · 客厅电视'].map((n, i) => `<button class="pop-q ${i === 1 ? 'on' : ''}" data-act="toast" data-msg="已切换到 ${n}" data-icon="volume"><b>${n}</b>${ic('check')}</button>`).join('')}
      <div class="pop-g">音量均衡</div><div class="pop-row">${seg(['关闭', '按曲目', '按专辑'], D.set.loudness === 'off' ? '关闭' : D.set.loudness === 'track' ? '按曲目' : '按专辑', 'setLoud')}</div>`,
  }[p.v];
  return `<div class="ov clear" data-act="closeOv"></div><div class="pop pop-${p.v}" style="${p.style || ''}">${body ? body() : ''}</div>`;
}
function ctxMenu() {
  const c = D.ctx, s = c.id != null ? SONGS[c.id] : null, n = D.sel.size > 1 && D.sel.has(+c.id) ? D.sel.size : 1;
  const items = {
    song:[['play', '播放', 'play', 'Enter'], ['next', '下一首播放', 'playNext'], ['plus', '加入歌单', 'sub'], '-', [D.liked.has(+c.id) ? 'heartf' : 'heart', D.liked.has(+c.id) ? '取消收藏' : '收藏', 'like', 'Ctrl+L'], ['download', '下载', 'toast'], ['quote', '分享歌词卡', 'toast'], '-',
      ['album', '查看专辑', 'go:collection'], ['user', '查看歌手', 'go:artist'], ['edit', '编辑标签', 'editTag'], ['link', '复制链接', 'toast', 'Ctrl+C'], '-', ['close', '不感兴趣', 'toast']],
    playlist:[['play', '播放全部', 'playAll'], ['queue', '加入队列', 'toast'], ['heart', '收藏歌单', 'toast'], ['link', '复制链接', 'toast']],
    myPl:[['play', '播放全部', 'playAll'], ['edit', '重命名', 'toast'], ['refresh', '刷新封面', 'toast'], ['download', '导出', 'toast'], '-', ['trash', '删除歌单', 'toast']],
  }[c.k] || [];
  return `<div class="ov clear" data-act="closeOv" data-ctxov="1"></div><div class="ctx" style="left:${c.x}px;top:${c.y}px">
    ${n > 1 ? `<div class="ctx-h">已选 ${n} 首</div>` : s ? `<div class="ctx-h">${cover(s, 28)}<div><b>${s.t}</b><small>${s.a}</small></div></div>` : ''}
    ${items.map(x => x === '-' ? '<i class="ctx-sep"></i>' : x[2] === 'sub'
      ? `<div class="ctx-it sub">${ic(x[0])}<span>${x[1]}</span>${ic('right')}<div class="ctx-subm">${MY.map(p => `<button class="ctx-it" data-act="addTo" data-id="${p.id}">${p.ic ? ic('heartf') : `<span class="pl-ic" style="${coverStyle(p.h, p.v)}"></span>`}<span>${p.t}</span></button>`).join('')}<i class="ctx-sep"></i><button class="ctx-it" data-act="dlg" data-v="newPl">${ic('plus')}<span>新建歌单…</span></button></div></div>`
      : `<button class="ctx-it" data-act="${x[2].split(':')[0]}" data-v="${x[2].split(':')[1] || ''}" data-id="${c.id ?? ''}" data-msg="${x[1]}${n > 1 ? ` · ${n} 首` : ''}" data-icon="${x[0]}">${ic(x[0])}<span>${x[1]}${n > 1 && x[2] !== 'go' ? ` ${n} 首` : ''}</span>${x[3] ? `<kbd>${x[3]}</kbd>` : ''}</button>`).join('')}</div>`;
}
const DLG = {
  close:() => `<div class="dl-ic">${ic('logout')}</div><h3>关闭 Lyra？</h3><p>选择关闭窗口时的行为。之后可在 设置 → 通用 中修改。</p>
    <div class="dl-opts"><button class="on" data-act="pickClose" data-v="tray">${ic('tray')}<b>最小化到托盘</b><small>继续播放音乐</small></button><button data-act="pickClose" data-v="quit">${ic('close')}<b>退出应用</b><small>停止播放并退出</small></button></div>
    <label class="ck-row"><span class="ck on">${ic('check')}</span>记住我的选择</label><div class="row-btns"><button class="btn sec" data-act="closeDlg">取消</button><button class="btn pri" data-act="pickClose" data-v="tray">确定</button></div>`,
  newPl:() => `<h3>新建歌单</h3><div class="np"><div class="cv" style="${coverStyle(140, 2)}"></div><div style="flex:1"><label class="fld-d"><span>名称</span><input id="dlgIn" value="周末下午" autofocus></label><label class="fld-d"><span>描述</span><input placeholder="可选"></label><label class="ck-row"><span class="ck">${ic('check')}</span>设为私密</label></div></div><div class="row-btns"><button class="btn sec" data-act="closeDlg">取消</button><button class="btn pri" data-act="newPlDone">创建</button></div>`,
  importPl:() => `<h3>导入歌单</h3><p>粘贴歌单分享链接或输入 ID，会自动识别平台。</p><div class="seg-pl">${PL3.map((p, i) => `<button class="${i === (D.dlgP || 0) ? 'on' : ''}" data-act="dlgP" data-v="${i}">${pb(p, 22)}${p.n}</button>`).join('')}</div>
    <label class="fld-d"><span>链接或 ID</span><input id="dlgIn" value="${D.dlgVal || ''}" placeholder="https://… 或 7458102936"></label>${D.dlgVal ? `<div class="okline">${ic('check')}已识别为 ${PL3[D.dlgP || 0].n} 歌单 · 42 首</div>` : ''}
    <div class="row-btns"><button class="btn sec" data-act="closeDlg">取消</button><button class="btn sec" data-act="dlgPaste">${ic('copy')}粘贴</button><button class="btn pri" data-act="importDone">导入</button></div>`,
  platLogin:() => { const p = platBy(D.dlgPlat || 'qq'); return `<div class="pl-login" style="--pc:${p.c}">${pb(p, 44)}<h3>登录${p.n}</h3><p>用 ${p.n} App 扫码。登录信息只保存在本机。</p><div class="qr-d">${qrSvg(p.id.length * 7)}<i class="qr-scan"></i></div><div class="row-btns"><button class="btn sec" data-act="closeDlg">取消</button><button class="btn pri" data-act="platLoginDone" data-v="${p.id}">原型演示：模拟扫码成功</button></div></div>`; },
  restore:() => `<div class="dl-ic warn">${ic('info')}</div><h3>恢复这份备份？</h3><p>当前的收藏和歌单会被覆盖。恢复前会自动备份当前数据。</p><div class="row-btns"><button class="btn sec" data-act="closeDlg">取消</button><button class="btn danger" data-act="closeDlgToast" data-msg="已恢复备份">恢复</button></div>`,
  clearHist:() => `<div class="dl-ic warn">${ic('trash')}</div><h3>清空播放记录？</h3><p>听歌统计不受影响。</p><div class="row-btns"><button class="btn sec" data-act="closeDlg">取消</button><button class="btn danger" data-act="closeDlgToast" data-msg="已清空播放记录">清空</button></div>`,
};
const dialog = () => `<div class="ov dim" data-act="closeDlg"></div><div class="dlg dlg-${D.dlg}">${DLG[D.dlg] ? DLG[D.dlg]() : ''}</div>`;
function qrSvg(seed) {
  let a = seed * 9301 + 49297; const r = () => ((a = (a * 16807) % 2147483647) / 2147483647); const N = 25, c = [];
  const f = (x, y) => { for (let i = 0; i < 7; i++) for (let j = 0; j < 7; j++) if (i === 0 || i === 6 || j === 0 || j === 6 || (i > 1 && i < 5 && j > 1 && j < 5)) c.push([x + i, y + j]); };
  f(0, 0); f(N - 7, 0); f(0, N - 7);
  for (let i = 0; i < N; i++) for (let j = 0; j < N; j++) { const inF = (i < 8 && j < 8) || (i > N - 9 && j < 8) || (i < 8 && j > N - 9); if (!inF && r() > .52) c.push([i, j]); }
  return `<svg viewBox="-1 -1 ${N + 2} ${N + 2}">${c.map(([x, y]) => `<rect x="${x}" y="${y}" width="1.02" height="1.02" rx=".2"/>`).join('')}</svg>`;
}

/* ================= 动作 ================= */
function go(p, a = {}) { if (D.route.p === p && JSON.stringify(D.route.a) === JSON.stringify(a)) return; D.back.push(D.route); D.fwd = []; D.route = { p, a }; D.sel.clear(); D.sort = { k:null, dir:1 }; D._stag = true; closeOverlays(); }
function closeOverlays() { D.picker = false; D.pal = false; D.pop = null; D.ctx = null; }
function playSong(id) { if (!D.queue.includes(id)) D.queue.splice(D.queue.indexOf(D.cur) + 1, 0, id); D.cur = id; D.pos = 0; D.playing = true; D._li = -1; }
function step(d) { const q = D.queue, i = q.indexOf(D.cur); D.cur = D.mode === 'shuffle' ? q[(i + 3 + Math.floor(Math.random() * (q.length - 2))) % q.length] : q[(i + d + q.length) % q.length]; D.pos = 0; D._li = -1; }
const ACT = {
  go:d => { if (d.v === 'collection' || d.v === 'artist') go(d.v, { id:+(d.id || 0) }); else go(d.v); render(); },
  goSmart:d => { D.smartSel = +d.i; go('smart'); render(); },
  goSet:d => { go('settings'); D.setCat = d.v || '通用'; render(); },
  nav:d => { const from = +d.v < 0 ? D.back : D.fwd, to = +d.v < 0 ? D.fwd : D.back; if (!from.length) return; to.push(D.route); D.route = from.pop(); D._stag = true; closeOverlays(); render(); },
  tgSb:() => { D.sb = !D.sb; render(); },
  rp:d => { if (D.rpOpen && D.rp === d.v && ['queue', 'lyrics'].includes(d.v) && d.fromBar !== '0') { D.rpOpen = false; } else { D.rpOpen = true; D.rp = d.v; } D._li = -1; render(); },
  rpClose:() => { D.rpOpen = false; render(); },
  play:(d, e) => { e && e.stopPropagation(); playSong(+d.id); closeOverlays(); render(); },
  playAll:(d, e) => { e && e.stopPropagation(); D.queue = SONGS.slice(0, 16).map(s => s.id); playSong(D.queue[0]); closeOverlays(); render(); toast('开始播放 · 16 首', 'play'); },
  playNext:d => { const id = +d.id; D.queue = D.queue.filter(x => x !== id); D.queue.splice(D.queue.indexOf(D.cur) + 1, 0, id); closeOverlays(); render(); toast(`「${SONGS[id].t}」将在下一首播放`, 'next'); },
  toggle:() => { D.playing = !D.playing; render(); },
  next:() => { step(1); render(); }, prev:() => { if (D.pos > 3) D.pos = 0; else step(-1); render(); },
  mode:() => { const m = ['loop', 'one', 'shuffle', 'order']; D.mode = m[(m.indexOf(D.mode) + 1) % 4]; render(); toast({ loop:'列表循环', one:'单曲循环', shuffle:'随机播放', order:'顺序播放' }[D.mode], { loop:'repeat', one:'repeat1', shuffle:'shuffle', order:'order' }[D.mode]); },
  like:(d, e) => { e && e.stopPropagation(); const ids = D.sel.size > 1 && D.sel.has(+d.id) ? [...D.sel] : [d.id !== '' && d.id != null ? +d.id : D.cur]; const on = !D.liked.has(ids[0]); ids.forEach(id => on ? D.liked.add(id) : D.liked.delete(id)); closeOverlays(); render(); toast(on ? `已收藏${ids.length > 1 ? ` ${ids.length} 首` : ''}` : '已取消收藏', on ? 'heartf' : 'heart'); },
  sortBy:d => { D.sort = D.sort.k === d.v ? (D.sort.dir > 0 ? { k:d.v, dir:-1 } : { k:null, dir:1 }) : { k:d.v, dir:1 }; render(); },
  ctxBtn:(d, e) => { e.stopPropagation(); const r = e.target.closest('button').getBoundingClientRect(); openCtx('song', d.id, r.left, r.bottom); },
  addTo:d => { const p = MY.find(x => x.id === +d.id); const n = D.sel.size || 1; p.n += n; closeOverlays(); render(); toast(`已加入「${p.t}」· ${n} 首`, 'plus'); },
  editTag:d => { D.editTag = +d.id; D.rpOpen = true; D.rp = 'tag'; closeOverlays(); render(); },
  toast:d => { closeOverlays(); render(); toast(d.msg || '完成', d.icon || 'check'); },
  closeOv:() => { closeOverlays(); render(); },
  picker:() => { D.picker = !D.picker; D.pal = false; render(); },
  setPlat:d => { D.plat = d.v; D.script = 'auto'; render(); if (D.route.p === 'discover') { D.loading = true; setTimeout(() => { D.loading = false; D._stag = true; render(); }, 650); } },
  setScript:d => { D.script = d.v; render(); setTimeout(() => { D.picker = false; render(); toast(`解析：${curScript().n} · ${plat().n}`, 'code'); }, 240); },
  palOpen:() => { if (D.pal) return; D.pal = true; D.picker = false; D.pIdx = 0; D._focusQ = true; render(); },
  doSearch:() => { const q = D.q.trim(); if (!q) return; D.pal = false; go('search', { q }); D.sType = '单曲'; D.sPlat = 'all'; render(); document.querySelector('#q')?.blur(); },
  sq:d => { D.q = d.q; ACT.doSearch(); },
  sType:d => { D.sType = d.v; D._stag = true; render(); }, sPlat:d => { D.sPlat = d.v; D._stag = true; render(); },
  pop:(d, e) => { e && e.stopPropagation(); if (D.pop && D.pop.v === d.v) { D.pop = null; render(); return; } const r = e.target.closest('button').getBoundingClientRect(), w = document.getElementById('win').getBoundingClientRect(), sc = w.width / document.getElementById('win').offsetWidth;
    const x = (r.left - w.left) / sc, y = (r.top - w.top) / sc, bottom = (r.bottom - w.top) / sc;
    const style = ['quality', 'output'].includes(d.v) ? `right:${Math.max(12, 1440 - x - 120)}px;bottom:${900 - y + 10}px` : `right:${Math.max(12, 1440 - x - 40)}px;top:${bottom + 8}px`;
    closeOverlays(); D.pop = { v:d.v, style }; render(); },
  setQ:d => { D.quality = d.v; D.pop = null; render(); toast(`音质：${d.v}`, 'hd'); },
  setLoud:d => { D.set.loudness = { 关闭:'off', 按曲目:'track', 按专辑:'album' }[d.v]; render(); },
  syncNow:() => { D.sync = 'busy'; render(); setTimeout(() => { D.sync = 'ok'; render(); toast('同步完成', 'cloud'); }, 1400); },
  syncDemo:() => { D.sync = 'conflict'; render(); }, syncFix:() => { D.sync = 'ok'; render(); toast('冲突已解决', 'check'); },
  tgTheme:() => { D.theme = D.theme === 'dark' ? 'light' : 'dark'; D.set.theme = D.theme; closeOverlays(); render(); },
  tgSet:(d, e) => { e && e.stopPropagation(); D.set[d.k] = !D.set[d.k]; if (d.k === 'cloud') D.set.cloud = D.set.cloud; render(); },
  tgMax:() => { D.maximized = !D.maximized; render(); },
  close:() => { D.dlg = 'close'; render(); },
  pickClose:d => { D.dlg = null; render(); toast(d.v === 'quit' ? '已退出（原型不会真的关闭）' : '已最小化到托盘，音乐继续播放', d.v === 'quit' ? 'close' : 'tray'); },
  dlg:d => { closeOverlays(); D.dlg = d.v; D.dlgVal = ''; if (d.p) D.dlgPlat = d.p; render(); },
  closeDlg:() => { D.dlg = null; render(); }, closeDlgToast:d => { D.dlg = null; render(); toast(d.msg, 'check'); },
  dlgP:d => { D.dlgP = +d.v; D.dlgVal = document.getElementById('dlgIn')?.value || ''; render(); },
  dlgPaste:() => { D.dlgVal = ['https://music.163.com/playlist?id=7458102936', 'https://y.qq.com/n/ryqq/playlist/8837261540', 'https://www.kugou.com/songlist/gcid_3zk8q2xz/'][D.dlgP || 0]; render(); },
  importDone:() => { MY.splice(1, 0, { id:300 + MY.length, t:'后摇与星空', n:42, h:225, v:0 }); D.dlg = null; render(); toast('已导入「后摇与星空」· 42 首', 'download'); },
  newPlDone:() => { const n = document.getElementById('dlgIn')?.value || '新建歌单'; MY.splice(1, 0, { id:400 + MY.length, t:n, n:0, h:140, v:2 }); D.dlg = null; render(); toast(`已创建「${n}」`, 'check'); },
  platLoginDone:d => { D.login[d.v] = '阿栗'; D.dlg = null; render(); toast(`已登录${platBy(d.v).n}`, 'check'); },
  logoutPlat:d => { delete D.login[d.v]; render(); toast(`已退出${platBy(d.v).n}`, 'logout'); },
  tgDeskLyric:() => { D.deskLyric = !D.deskLyric; closeOverlays(); render(); toast(D.deskLyric ? '桌面歌词已显示' : '桌面歌词已隐藏', 'lyric'); },
  seekLine:d => { D.pos = LYRICS[+d.i].t + .05; D._li = -1; },
  homeTab:d => { D.homeTab = d.v; D._stag = true; render(); },
};
function openCtx(k, id, cx, cy) {
  const w = document.getElementById('win'), r = w.getBoundingClientRect(), sc = r.width / w.offsetWidth;
  let x = (cx - r.left) / sc, y = (cy - r.top) / sc; x = Math.min(x, 1440 - 250); y = Math.min(y, 900 - 420);
  closeOverlays(); D.ctx = { k, id, x, y };
  if (k === 'song' && !D.sel.has(+id)) { D.sel.clear(); }
  render();
}

/* ================= 事件 ================= */
function bindEvents() {
  const win = document.getElementById('win');
  win.addEventListener('click', e => {
    const el = e.target.closest('[data-act]'); const row = e.target.closest('.tr[data-row]');
    if (row && !e.target.closest('button')) { selectRow(+row.dataset.row, e); return; }
    if (!el) { if (D.sel.size && !e.target.closest('.tbl,.selbar')) { D.sel.clear(); render(); } return; }
    const fn = ACT[el.dataset.act]; if (fn) { e.stopPropagation(); fn(el.dataset, e); }
  });
  win.addEventListener('dblclick', e => {
    const row = e.target.closest('.tr[data-row]'); if (row) { playSong(+row.dataset.row); render(); return; }
    if (e.target.closest('.tb.drag') && !e.target.closest('.nodrag')) ACT.tgMax();
    if (D.mini && !e.target.closest('button')) { D.mini = false; render(); }
  });
  win.addEventListener('contextmenu', e => {
    if (D.view === 'fx') { e.preventDefault(); D.shelf = !D.shelf; D.shelfOpen = false; render(); return; }
    const t = e.target.closest('[data-ctx]'); if (!t) return; e.preventDefault();
    openCtx(t.dataset.ctx, t.dataset.id, e.clientX, e.clientY);
  });
  // 拖拽歌曲到侧边栏歌单
  win.addEventListener('dragstart', e => { const r = e.target.closest('[data-row]'); if (!r) return; const id = +r.dataset.row; if (!D.sel.has(id)) { D.sel.clear(); D.sel.add(id); }
    e.dataTransfer.setData('text/plain', [...D.sel].join(',')); const g = document.getElementById('dragghost'); g.textContent = D.sel.size > 1 ? `${D.sel.size} 首歌曲` : SONGS[id].t; e.dataTransfer.setDragImage(g, 10, 10); win.classList.add('dragging'); });
  win.addEventListener('dragend', () => win.classList.remove('dragging'));
  win.addEventListener('dragover', e => { const t = e.target.closest('[data-drop]'); if (t) { e.preventDefault(); win.querySelectorAll('.drop-on').forEach(x => x.classList.remove('drop-on')); t.classList.add('drop-on'); } });
  win.addEventListener('drop', e => { const t = e.target.closest('[data-drop]'); if (!t) return; e.preventDefault(); const n = e.dataTransfer.getData('text/plain').split(',').length; const p = MY.find(x => x.id === +t.dataset.drop) || SMART.find(x => x.id === +t.dataset.drop);
    t.classList.remove('drop-on'); if (p) { p.n += n; render(); toast(`已加入「${p.t}」· ${n} 首`, 'plus'); } });
  // 搜索输入
  win.addEventListener('input', e => {
    if (e.target.id === 'q') { if (e.isComposing) return; D.q = e.target.value; D.pal = true; D.pIdx = 0; D._focusQ = true; render(); }
    if (e.target.dataset.setq != null) { D.setQ = e.target.value; D._focusSet = true; renderSettingsOnly(); }
    if (e.target.dataset.rng) { const k = e.target.dataset.rng; D.set[k] = +e.target.value; const o = win.querySelector(`[data-out="${k}"]`); if (o) o.textContent = e.target.dataset.fmt ? e.target.dataset.fmt.replace('{}', e.target.value) : e.target.value; e.target.style.setProperty('--v', (e.target.value - e.target.min) / (e.target.max - e.target.min) * 100 + '%'); }
  });
  win.addEventListener('compositionend', e => { if (e.target.id === 'q') { D.q = e.target.value; D.pal = true; D._focusQ = true; render(); } });
  // 进度条 / 音量拖动
  let sk = null;
  win.addEventListener('pointerdown', e => { const p = e.target.closest('[data-seek]'); if (!p) return; sk = { p, k:p.dataset.seek }; p.classList.add('drag'); p.setPointerCapture(e.pointerId); seekMove(e); });
  const seekMove = e => { if (!sk) return; const r = sk.p.getBoundingClientRect(), v = Math.min(1, Math.max(0, (e.clientX - r.left) / r.width)); sk.v = v; sk.p.querySelector('.fill').style.width = v * 100 + '%'; const th = sk.p.querySelector('.th'); if (th) th.style.left = v * 100 + '%';
    if (sk.k === 'song') win.querySelectorAll('[data-b=pos]').forEach(x => x.textContent = fmt(v * song().dur)); else { D.vol = v; } };
  win.addEventListener('pointermove', seekMove);
  win.addEventListener('pointerup', () => { if (!sk) return; if (sk.k === 'song') { D.pos = sk.v * song().dur; D._li = -1; } sk.p.classList.remove('drag'); sk = null; });
  // 键盘
  document.addEventListener('keydown', e => {
    const inInput = e.target.closest && e.target.closest('input,textarea');
    if (D.rec) { e.preventDefault(); recordKey(e); return; }
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k' || e.key === 'F1') { e.preventDefault(); ACT.palOpen(); return; }
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'b' && !D.mini && !D.big) { e.preventDefault(); ACT.tgSb(); return; }
    if (D.pal) {
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); D.pIdx = Math.max(0, Math.min((D._palItems || []).length - 1, D.pIdx + (e.key === 'ArrowDown' ? 1 : -1))); D._focusQ = true; render(); return; }
      if (e.key === 'Enter') { e.preventDefault(); const b = document.querySelector(`.pal-it[data-pi="${Math.min(D.pIdx, (D._palItems || []).length - 1)}"]`); b && b.click(); return; }
    }
    if (e.key === 'Escape') { e.preventDefault(); escBack(); return; }
    if (D.big) { bigKey(e); return; }
    if (inInput) return;
    if (e.key === ' ') { e.preventDefault(); ACT.toggle(); }
    if ((e.ctrlKey && e.key === 'ArrowRight') || (e.altKey && e.key === 'ArrowRight')) ACT.next();
    if ((e.ctrlKey && e.key === 'ArrowLeft') || (e.altKey && e.key === 'ArrowLeft')) ACT.prev();
    if (e.ctrlKey && e.key.toLowerCase() === 'a' && document.querySelector('.content .tbl')) { e.preventDefault(); document.querySelectorAll('.content .tbl [data-row]').forEach(r => D.sel.add(+r.dataset.row)); render(); }
    if (D.view === 'fx' && /^[1-4]$/.test(e.key)) { D.fx = FX_PRESETS[+e.key - 1].k; S.particle = D.fx; render(); }
  });
  // 动效模式沉浸：鼠标静止 3 秒隐藏控件
  let idleT; win.addEventListener('pointermove', () => { if (D.view !== 'fx') return; if (D.idle) { D.idle = false; win.querySelector('.player')?.classList.remove('idle'); } clearTimeout(idleT); idleT = setTimeout(() => { if (D.view === 'fx' && !D.shelf) { D.idle = true; win.querySelector('.player')?.classList.add('idle'); } }, 3000); });
}
function escBack() {
  if (D.rec) { D.rec = null; renderSettingsOnly(); return; }
  if (D.ctx || D.pop || D.picker || D.pal) { closeOverlays(); render(); return; }
  if (D.dlg) { D.dlg = null; render(); return; }
  if (D.shelf) { if (D.shelfOpen) D.shelfOpen = false; else D.shelf = false; render(); return; }
  if (D.big) { D.big = false; render(); return; }
  if (D.view) { D.view = null; render(); return; }
  if (D.sel.size) { D.sel.clear(); render(); }
}
function selectRow(id, e) {
  const rows = [...document.querySelectorAll('.content .tbl [data-row]')].map(r => +r.dataset.row);
  if (e.shiftKey && D.anchor != null) { const a = rows.indexOf(D.anchor), b = rows.indexOf(id); D.sel.clear(); rows.slice(Math.min(a, b), Math.max(a, b) + 1).forEach(x => D.sel.add(x)); }
  else if (e.ctrlKey || e.metaKey) { D.sel.has(id) ? D.sel.delete(id) : D.sel.add(id); D.anchor = id; }
  else { D.sel.clear(); D.sel.add(id); D.anchor = id; }
  render();
}
const selBar = () => D.sel.size > 1 ? `<div class="selbar"><b>已选 ${D.sel.size} 首</b><button data-act="playAll">${ic('play')}播放</button><button data-act="playNext" data-id="${[...D.sel][0]}">${ic('next')}下一首播放</button><button data-act="ctxBtn" data-id="${[...D.sel][0]}">${ic('plus')}加入歌单</button><button data-act="like" data-id="${[...D.sel][0]}">${ic('heart')}收藏</button><button data-act="toast" data-msg="已加入下载 · ${D.sel.size} 首" data-icon="download">${ic('download')}下载</button><span>${kbd('Ctrl+A')} 全选 · ${kbd('Shift')} 连选 · ${kbd('Esc')} 取消</span><button class="x" data-act="clearSel">${ic('close')}</button></div>` : '';
ACT.clearSel = () => { D.sel.clear(); render(); };

/* ================= 每帧 ================= */
let lastT = performance.now();
function tick(now) {
  const dt = Math.min(.1, (now - lastT) / 1000); lastT = now;
  if (D.playing) { D.pos += dt; if (D.pos >= song().dur) { step(1); render(); } }
  const s = song(), p = D.pos / s.dur;
  document.querySelectorAll('[data-b=pos]').forEach(x => { if (!x.closest('.drag') && !document.querySelector('[data-seek].drag')) x.textContent = fmt(D.pos); });
  document.querySelectorAll('[data-seek=song]:not(.drag)').forEach(x => { x.querySelector('.fill').style.width = p * 100 + '%'; const th = x.querySelector('.th'); if (th) th.style.left = p * 100 + '%'; });
  document.querySelectorAll('[data-b=mfill]').forEach(x => x.style.width = p * 100 + '%');
  let k = -1; LYRICS.forEach((l, i) => { if (l.t <= D.pos) k = i; });
  const beat = D.playing ? Math.exp(-((D.pos * 112 / 60) % 1) * 5) : 0;
  document.documentElement.style.setProperty('--beat', beat.toFixed(3));
  if (k !== D._li) { D._li = k; lyricLayout(k); }
  if (k >= 0) { const L = LYRICS[k], fp = Math.min(1, Math.max(0, (D.pos - L.t) / (L.d * .92))); document.querySelectorAll('[data-li].on .w, .dl-cur .w').forEach(w => w.style.setProperty('--p', fp.toFixed(3))); }
  if (typeof playerTick === 'function') playerTick(k, beat);
  requestAnimationFrame(tick);
}
function lyricLayout(k) {
  document.querySelectorAll('[data-lyr]').forEach(box => {
    box.querySelectorAll('[data-li]').forEach(el => { const i = +el.dataset.li; el.classList.toggle('on', i === k); el.classList.toggle('near', Math.abs(i - k) === 1); });
    const cur = box.querySelector(`[data-li="${Math.max(0, k)}"]`); if (!cur) return;
    if (box.dataset.mode === 'stagger') { const off = box.clientHeight * .34 - cur.offsetTop - cur.offsetHeight / 2; box.querySelectorAll('[data-li]').forEach(el => { const d = +el.dataset.li - k; el.style.transitionDelay = d >= 0 ? Math.min(d, 8) * 45 + 'ms' : '0ms'; el.style.transform = `translateY(${off}px)`; el.style.filter = D.set.lblur && d ? `blur(${Math.min(Math.abs(d), 4) * .5}px)` : 'none'; }); }
    else box.scrollTo({ top:cur.offsetTop - box.clientHeight * .36, behavior:'smooth' });
  });
  const dl = document.getElementById('desklyric');
  if (dl) { const L = LYRICS[Math.max(0, k)], N = LYRICS[k + 1]; dl.querySelector('.dl-cur').innerHTML = `<span class="w">${L.o}</span>`; dl.querySelector('.dl-next').textContent = N ? N.o : ''; }
}
