/* 全屏设置页：左侧分类 + 顶部搜索（搜索覆盖所有字段）。字段名对应 sollin.json → settings。 */
const SET_CATS = [
  ['通用', 'gear'], ['外观', 'palette'], ['播放与音质', 'play'], ['音效', 'sliders'], ['歌词', 'quote'], ['桌面歌词', 'lyric'], ['动效模式', 'sparkle'],
  ['快捷键', 'cmd'], ['下载与存储', 'download'], ['同步与备份', 'cloud'], ['高级', 'code'], ['关于', 'info'],
];
const rng = (k, min, max, step, f = '{}') => `<div class="rng"><input type="range" min="${min}" max="${max}" step="${step}" value="${D.set[k]}" data-rng="${k}" data-fmt="${f}" style="--v:${(D.set[k] - min) / (max - min) * 100}%"><output data-out="${k}">${f.replace('{}', D.set[k])}</output></div>`;
const segS = (k, opts, map) => seg(opts, map ? Object.keys(map).find(x => map[x] === D.set[k]) || opts[0] : D.set[k], 'setSeg" data-k="' + k + (map ? '" data-map="' + encodeURIComponent(JSON.stringify(map)) : ''));
const F = (cat, key, label, desc, ctl) => ({ cat, key, label, desc, ctl });
const FIELDS = () => [
  F('通用', 'closeAction', '关闭窗口时', '点关闭按钮时如何处理正在播放的音乐', segS('closeAction', ['每次询问', '最小化到托盘', '直接退出'], { 每次询问:'ask', 最小化到托盘:'tray', 直接退出:'quit' })),
  F('通用', 'checkUpdatesOnStartup', '启动时检查更新', '', sw('checkUpd', D.set.checkUpd)),
  F('通用', 'checkSourceUpdatesOnStartup', '启动时检查音源更新', '', sw('checkSrc', D.set.checkSrc)),
  F('通用', 'showTaskbarProgress', '任务栏显示播放进度', '播放、暂停和错误状态同步到任务栏图标', sw('taskbarProgress', D.set.taskbarProgress)),
  F('通用', 'taskbarPreview', '任务栏缩略图工具栏', '缩略图下方显示 上一首 / 播放 / 下一首', segS('tbp', ['默认', '封面', '关闭'])),
  F('外观', 'theme', '主题', '', segS('theme', ['跟随系统', '浅色', '深色'], { 跟随系统:'system', 浅色:'light', 深色:'dark' })),
  F('外观', 'accent', '主题色', '按钮、进度条、歌词高亮与动效 accent', `<div class="sw-c">${ACCENTS.map((a, i) => `<button class="${D.accent === i ? 'on' : ''}" style="background:${a.c}" data-act="setAccent" data-v="${i}" title="${a.n}"></button>`).join('')}</div>`),
  F('外观', 'animationEnabled', '界面动效', '页面切换、卡片入场与交互反馈动画', sw('animation', D.set.animation)),
  F('外观', 'uiFontSize', '界面字号', '', segS('uiFontSize', ['小', '偏小', '默认', '偏大', '大'])),
  F('外观', 'uiFont', '界面字体', '系统字体或导入 .ttf / .otf', `<div class="ctl-row"><button class="dd">系统默认${ic('down')}</button><button class="btn sec sm" data-act="toast" data-msg="选择字体文件" data-icon="font">${ic('download')}导入字体</button></div>`),
  F('外观', 'playerBackgroundMode', '播放页背景', '', segS('bgMode', ['静态流光', '动态流光', '模糊封面', '纯色'])),
  F('播放与音质', 'preferredQuality', '首选音质', '不可用时按智能换源规则降级', segS('quality', ['flac', '320k', '128k'])),
  F('播放与音质', 'smart', '智能换源', '降音质 → 换脚本 → 换平台 → 下一首', sw('smart', D.set.smart)),
  F('播放与音质', 'autoSkipOnError', '解析失败时自动下一首', '', sw('autoSkip', D.set.autoSkip)),
  F('播放与音质', 'fadeEnabled', '淡入淡出', '切歌和暂停时平滑过渡', sw('fade', D.set.fade)),
  F('播放与音质', 'fadeInMs', '淡入时长', '', rng('fadeIn', 0, 2000, 50, '{} ms')),
  F('播放与音质', 'fadeOutMs', '淡出时长', '', rng('fadeOut', 0, 2000, 50, '{} ms')),
  F('播放与音质', 'playbackRate', '播放速度', '', rng('rate', .5, 2, .05, '{}×')),
  F('播放与音质', 'preservesPitch', '变速不变调', '', sw('pitch', D.set.pitch)),
  F('播放与音质', 'loudnessNormalization', '响度均衡', '', segS('loudness', ['关闭', '按曲目', '按专辑'], { 关闭:'off', 按曲目:'track', 按专辑:'album' })),
  F('播放与音质', 'loudnessPreampDb', '前置增益', '', rng('preamp', -12, 12, 1, '{} dB')),
  F('播放与音质', 'loudnessPreventClipping', '防止削波', '', sw('preventClip', D.set.preventClip)),
  F('播放与音质', 'audioOutputDeviceId', '输出设备', '', `<button class="dd">耳机 (Sony WH-1000XM6)${ic('down')}</button>`),
  F('播放与音质', 'sleepTimerMinutes', '睡眠定时', '到点后停止播放', segS('sleep', ['关闭', '15', '30', '60', '90'])),
  F('音效', 'equalizer', '均衡器', '10 段 · 拖动圆点调节 ±12 dB', `<div class="eq-d">${D.set.eq.map((v, i) => `<div class="eqb"><small>${v > 0 ? '+' : ''}${v}</small><div class="eqt"><b style="height:${Math.abs(v) / 12 * 50}%;${v >= 0 ? 'bottom:50%' : 'top:50%'}"></b><i style="top:${50 - v / 12 * 46}%"></i></div><small>${['31', '62', '125', '250', '500', '1k', '2k', '4k', '8k', '16k'][i]}</small></div>`).join('')}</div>`),
  F('音效', 'reverbPreset', '混响', '', segS('reverb', ['无', '房间', '大厅', '教堂'])),
  F('音效', 'spatialEnabled', '空间音频', '耳机下模拟声场环绕', sw('spatial', D.set.spatial)),
  F('音效', 'visualization', '频谱可视化', '在播放页显示实时频谱', sw('viz', D.set.viz)),
  F('歌词', 'lyricFontSize', '字号', '', rng('lfs', 32, 96, 1, '{} px')),
  F('歌词', 'lyricFontWeight', '字重', '', rng('lfw', 400, 900, 100)),
  F('歌词', 'lyricLineSpacing', '行距', '', rng('lgap', 0, 48, 1, '{} px')),
  F('歌词', 'lyricInactiveOpacity', '非当前行透明度', '', rng('lop', 0, 1, .05)),
  F('歌词', 'lyricBlurEnabled', '非当前行模糊', '', sw('lblur', D.set.lblur)),
  F('歌词', 'lyricTextAlign', '对齐', '', segS('lalign', ['左', '居中', '右'], { 左:'left', 居中:'center', 右:'right' })),
  F('歌词', 'trans', '显示翻译', '', sw('trans', D.set.trans)),
  F('歌词', 'roma', '显示罗马音', '', sw('roma', D.set.roma)),
  F('桌面歌词', 'desktopLyric.enabled', '显示桌面歌词', '全局快捷键 Ctrl+Alt+0', `<button class="sw ${D.deskLyric ? 'on' : ''}" data-act="tgDeskLyric"></button>`),
  F('桌面歌词', 'desktopLyric.locked', '锁定（点击穿透）', 'Ctrl+Alt+-', `<button class="sw ${D.deskLock ? 'on' : ''}" data-act="tgDeskLock"></button>`),
  F('桌面歌词', 'desktopLyric.alwaysOnTop', '置顶', 'Ctrl+Alt+=', sw('dlTop', D.set.dlTop)),
  F('桌面歌词', 'desktopLyric.hoverHide', '鼠标移入时隐藏', '避免挡住下方操作', sw('dlHoverHide', D.set.dlHoverHide)),
  F('桌面歌词', 'desktopLyric.showInTaskbar', '在任务栏显示', '', sw('dlTaskbar', D.set.dlTaskbar)),
  F('桌面歌词', 'desktopLyric.fontSize', '字号', '', rng('dlFs', 18, 64, 1, '{} px')),
  F('桌面歌词', 'desktopLyric.stroke', '文字描边', '', sw('dlStroke', D.set.dlStroke)),
  F('桌面歌词', 'menuBarLyric', '状态栏歌词（macOS）', '', sw('menuBar', D.set.menuBar)),
  F('动效模式', 'detailFxMode', '打开播放页时默认进入动效模式', '', sw('fxOn', D.set.fxOn)),
  F('动效模式', 'detailFx.perf', '性能档位', '高 33k 点 + 泛光 · 中 16k · 省电 8k 关泛光', segS('fxPerf', ['高', '中', '省电', '自动'])),
  F('动效模式', 'detailFx.shield', '歌词区避让', '落在歌词框内的粒子自动压暗', sw('fxShield', D.set.fxShield)),
  F('动效模式', 'detailFx.bloom', '泛光', '', sw('fxBloom', D.set.fxBloom)),
  F('动效模式', 'detailFx.autoOrbit', '自动公转', '', sw('fxAuto', D.set.fxAuto)),
  F('快捷键', 'hotkeys.localEnabled', '启用应用内快捷键', '', sw('hkLocal', D.set.hkLocal)),
  ...[['togglePlay', '播放 / 暂停'], ['previous', '上一首'], ['next', '下一首'], ['focusSearch', '聚焦搜索 / 命令面板']].map(([k, n]) => F('快捷键', 'hotkeys.local.' + k, n, '应用内', hkBtn(k))),
  F('快捷键', 'hotkeys.globalEnabled', '启用全局快捷键', '应用在后台时也生效；开启后应用内同动作自动让位', sw('hkGlobal', D.set.hkGlobal)),
  ...[['gTogglePlay', '播放 / 暂停'], ['gPrev', '上一首'], ['gNext', '下一首'], ['gVolUp', '音量 +'], ['gVolDown', '音量 −'], ['gLyric', '显示 / 隐藏桌面歌词'], ['gLock', '锁定桌面歌词'], ['gTop', '桌面歌词置顶']].map(([k, n]) => F('快捷键', 'hotkeys.global.' + k, n, k === 'gLock' ? '<span class="err-t">已被「截图工具」占用</span>' : '全局', hkBtn(k, k === 'gLock'))),
  ...[['seekB', '快退 5 秒'], ['seekF', '快进 5 秒'], ['mute', '静音'], ['fav', '收藏当前歌曲']].map(([k, n]) => F('快捷键', k, n, '默认未绑定', hkBtn(k))),
  F('下载与存储', 'download.dir', '下载位置', 'D:\\Music\\Lyra', `<button class="btn sec sm" data-act="toast" data-msg="选择文件夹" data-icon="folder">更改</button>`),
  F('下载与存储', 'download.concurrency', '同时下载', '', rng('dlConc', 1, 8, 1, '{} 首')),
  F('下载与存储', 'download.embedCover', '内嵌封面与标签', 'FLAC / MP3 / M4A', sw('dlCover', D.set.dlCover)),
  F('下载与存储', 'download.lrc', '另存歌词文件', '同目录生成 .lrc', sw('dlLyric', D.set.dlLyric)),
  F('下载与存储', 'songCacheLimitMb', '缓存上限', '已用 1.8 GB', rng('cacheMb', 512, 8192, 256, '{} MB')),
  F('同步与备份', 'cloudSyncEnabled', '云同步', '收藏、歌单、播放进度', sw('cloud', D.set.cloud)),
  F('同步与备份', 'sync.autoBackup', '每天自动备份', '', sw('autoBackup', D.set.autoBackup)),
  F('同步与备份', 'webdav', 'WebDAV', '自建备份通道（坚果云 / Alist / Nextcloud）', `<button class="btn sec sm" data-act="toast" data-msg="打开 WebDAV 配置" data-icon="cloud">配置</button>`),
  F('高级', 'server', '服务器地址', 'API 基址，修改后立即生效', `<div class="ctl-row"><input class="inp" value="${D.set.server}"><button class="btn pri sm" data-act="toast" data-msg="已应用" data-icon="check">应用</button><button class="btn sec sm" data-act="toast" data-msg="已恢复默认" data-icon="refresh">恢复默认</button></div>`),
  F('高级', 'builtinSourceEnabled', '内置音源', '', sw('builtin', D.set.builtin)),
  F('高级', 'wallpaper', '动态壁纸', '把播放画面设为桌面壁纸（Windows）', `<button class="btn sec sm" data-act="toast" data-msg="壁纸模式已开启" data-icon="tv">开启</button>`),
  F('高级', 'logs', '应用日志', '', `<button class="btn sec sm" data-act="toast" data-msg="已打开日志目录" data-icon="folder">打开目录</button>`),
  F('关于', 'version', 'Lyra（暂名）', 'v2.4.0 · Electron 33 · 已是最新', `<button class="btn sec sm" data-act="toast" data-msg="已是最新版本" data-icon="check">检查更新</button>`),
];
const HK_KEY = { togglePlay:'togglePlay', previous:'previous', next:'next', focusSearch:'focusSearch' };
function hkBtn(k, bad) { return `<button class="hk ${D.rec === k ? 'rec' : ''} ${bad ? 'bad' : ''}" data-act="rec" data-v="${k}">${D.rec === k ? '<span class="rec-dot"></span>按下组合键…' : kbd(D.hk[k])}</button>${D.hk[k] ? `<button class="ib xs" data-act="hkClear" data-v="${k}">${ic('close')}</button>` : ''}`; }
function setBody() {
  const q = D.setQ.trim(), all = FIELDS();
  const list = q ? all.filter(f => (f.label + f.desc + f.key + f.cat).toLowerCase().includes(q.toLowerCase())) : all.filter(f => f.cat === D.setCat);
  const H = t => q ? t.replace(new RegExp(q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'ig'), m => `<em>${m}</em>`) : t;
  if (!list.length) return empty('search', `没有找到「${q}」相关的设置`, '试试「歌词」「快捷键」「音质」');
  let cat = '';
  return list.map(f => { const h = q && f.cat !== cat ? `<div class="set-g">${f.cat}</div>` : ''; cat = f.cat;
    return `${h}<div class="set-r" ${q ? `data-act="setJump" data-v="${f.cat}"` : ''}><div class="set-l"><b>${H(f.label)}</b>${f.desc ? `<small>${H(f.desc)}</small>` : ''}<code>${f.key}</code></div><div class="set-c">${f.ctl}</div></div>`; }).join('');
}
PAGES.settings = { full:true, render:() => `<div class="setp">
  <nav class="set-nav"><h1>设置</h1><div class="set-q">${ic('search')}<input data-setq placeholder="搜索 ${FIELDS().length} 项设置" value="${D.setQ}"></div>
    ${SET_CATS.map(([n, i]) => `<button class="${!D.setQ && D.setCat === n ? 'on' : ''}" data-act="setCat" data-v="${n}">${ic(i)}<span>${n}</span><em>${FIELDS().filter(f => f.cat === n).length}</em></button>`).join('')}</nav>
  <div class="set-body" key="${D.setCat}${D.setQ ? 'q' : ''}"><div class="set-h"><h2>${D.setQ ? `搜索「${D.setQ}」` : D.setCat}</h2>${D.setCat === '快捷键' && !D.setQ ? '<p>点击按钮后按下组合键即可录制；同一作用域内冲突会提示</p>' : ''}</div>${setBody()}</div></div>` };
function renderSettingsOnly() {
  const b = document.querySelector('.set-body'); if (!b) return render();
  b.innerHTML = `<div class="set-h"><h2>${D.setQ ? `搜索「${D.setQ}」` : D.setCat}</h2></div>${setBody()}`;
  document.querySelectorAll('.set-nav button[data-act=setCat]').forEach(x => x.classList.toggle('on', !D.setQ && x.dataset.v === D.setCat));
}
ACT.setCat = d => { D.setCat = d.v; D.setQ = ''; render(); };
ACT.setJump = d => { D.setCat = d.v; D.setQ = ''; render(); };
ACT.setSeg = d => { const map = d.map ? JSON.parse(decodeURIComponent(d.map)) : null; D.set[d.k] = map ? map[d.v] : d.v; if (d.k === 'theme') D.theme = D.set.theme === 'light' ? 'light' : 'dark'; render(); };
ACT.setAccent = d => { D.accent = +d.v; render(); };
ACT.tgDeskLock = () => { D.deskLock = !D.deskLock; render(); };
ACT.rec = (d, e) => { e && e.stopPropagation(); D.rec = d.v; renderSettingsOnly(); };
ACT.hkClear = d => { D.hk[d.v] = ''; renderSettingsOnly(); };
function recordKey(e) {
  if (['Control', 'Alt', 'Shift', 'Meta'].includes(e.key)) return;
  if (e.key === 'Escape') { D.rec = null; renderSettingsOnly(); return; }
  const parts = []; if (e.ctrlKey) parts.push('Ctrl'); if (e.altKey) parts.push('Alt'); if (e.shiftKey) parts.push('Shift');
  const name = { ArrowLeft:'←', ArrowRight:'→', ArrowUp:'↑', ArrowDown:'↓', ' ':'Space' }[e.key] || (e.key.length === 1 ? e.key.toUpperCase() : e.key); parts.push(name);
  const combo = parts.join('+'), k = D.rec, conflict = Object.entries(D.hk).find(([kk, v]) => v === combo && kk !== k && (kk[0] === 'g') === (k[0] === 'g'));
  if (conflict) { toast(`「${combo}」已被其他动作使用`, 'info'); return; }
  D.hk[k] = combo; D.rec = null; renderSettingsOnly(); toast(`已设置为 ${combo}`, 'cmd');
}
