/* 页面。每个页面 render() 返回内容区 HTML；full:true = 不显示右侧面板。 */
const PAGES = {};
const pageHead = (t, sub = '', right = '') => `<div class="ph"><div><h1>${t}</h1>${sub ? `<p>${sub}</p>` : ''}</div><div class="ph-r">${right}</div></div>`;
const skel = () => `<div class="skel"><i style="height:180px"></i><div class="sk-row">${'<i></i>'.repeat(6)}</div><div class="sk-list">${'<i></i>'.repeat(6)}</div></div>`;
const hl = q => t => { const i = t.toLowerCase().indexOf(q.toLowerCase()); return !q || i < 0 ? t : `${t.slice(0, i)}<em>${t.slice(i, i + q.length)}</em>${t.slice(i + q.length)}`; };
const PLAT_REC_D = { netease:['新碟上架', '官方榜', '曲风偏好', 'MV 排行'], qq:['适合现在听', '换个心情听', '新鲜上架', '巅峰榜'], kugou:['猜你喜欢', '换个心情听', '新歌首发', '酷狗榜单'] };
const HERO = { netease:[['每日推荐', '每天 06:00 按你的口味更新', 'daily'], ['心动模式', '从你喜欢的歌出发，越听越懂你', 'heart']], qq:[['每日 30 首', '每天为你挑 30 首', 'daily'], ['雷达推荐', '扫描口味，捕捉新歌', 'radar']], kugou:[['每日推荐', '今日为你精选', 'daily'], ['猜你喜欢', '私人电台，一直播下去', 'heart']] };

/* ---------- 推荐 ---------- */
PAGES.discover = { render:() => {
  const p = plat(), logged = isIn(p.id);
  if (D.loading) return pageHead('推荐') + skel();
  const hero = logged ? `<div class="hero-row blk">
      <div class="acct" data-act="pop" data-v="user" style="--pc:${p.c}"><span class="avatar">${D.login[p.id][0]}</span>${pb(p, 18)}<div><b>${D.login[p.id]}</b><small>Lv.8 · ${p.id === 'netease' ? '黑胶VIP' : p.id === 'qq' ? '绿钻' : '概念VIP'}</small></div><div class="acct-n"><b>128</b><small>喜欢</small></div><div class="acct-n"><b>20</b><small>歌单</small></div></div>
      ${HERO[p.id].map(([t, d, k], i) => `<div class="hc hc-${k}" style="--d:${i * 80}ms;${k === 'daily' ? coverStyle(300, 2) : ''}" data-act="go" data-v="collection" data-id="${i}">
        ${k === 'daily' ? `<div class="hc-date"><b>02</b><span>NOV · MON</span></div><div class="fan">${[4, 11, 17].map((id, j) => `<div class="cv" style="${coverStyle(SONGS[id].h, SONGS[id].v)};--i:${j}"></div>`).join('')}</div>` : k === 'heart' ? `<svg class="ekg" viewBox="0 0 160 44"><path d="M0 24h38l6-10 7 22 8-30 7 30 6-12h88"/></svg>` : `<div class="rdr"><i></i><i></i><b></b>${[[30, 40], [64, 22], [52, 70]].map(([x, y], j) => `<em style="left:${x}%;top:${y}%;--d:${j * .7}s"></em>`).join('')}</div>`}
        <div class="hc-t"><b>${t}</b><small>${d}</small></div><button class="hc-play" data-act="playAll">${ic('play')}</button></div>`).join('')}</div>`
    : `<div class="loginbar blk" style="--pc:${p.c};--pc2:${p.c2}"><i class="glow"></i>${pb(p, 40)}<div><b>登录${p.n}，解锁每日推荐、私人模式与你的歌单</b><small>不登录也可以搜索和播放 · 登录信息只保存在本机</small></div><button class="btn pri" data-act="dlg" data-v="platLogin" data-p="${p.id}">${ic('scan')}扫码登录</button></div>`;
  const mine = logged ? `${secH('我的歌单', '全部', 'data-act="go" data-v="collection" data-id="100"')}<div class="mypl blk">${MY.slice(0, 4).map((x, i) => `<div class="mp" data-act="go" data-v="collection" data-id="${x.id}" data-ctx="myPl" data-drop="${x.id}" style="--d:${i * 40}ms"><div class="cv" style="${coverStyle(x.h, x.v)}">${x.ic ? `<span>${ic('heartf')}</span>` : ''}</div><div><b>${x.t}</b><small>${x.n} 首</small></div><button class="mp-play" data-act="playAll">${ic('play')}</button></div>`).join('')}</div>` : '';
  const recs = PLAT_REC_D[p.id];
  return `${pageHead('推荐', `${pb(p, 16)} 来自${p.n} · 今天 09:12 更新`, `<button class="btn sec sm" data-act="setPlat" data-v="${p.id}">${ic('refresh')}刷新</button>`)}
  ${hero}${mine}
  <div class="tabs-line blk">${seg(['精选', '榜单', '歌单'], D.homeTab, 'homeTab')}</div>
  ${D.homeTab === '精选' ? `${secH(logged ? '推荐歌单' : '热门歌单', '歌单广场', 'data-act="go" data-v="square"')}<div class="grid-pl blk">${PLAYLISTS.slice(0, 6).map((x, i) => card(x, { i })).join('')}</div>
    <div class="two blk"><div>${secH('新歌速递', '播放全部', 'data-act="playAll"')}<div class="newsongs">${[8, 13, 19, 22, 3, 10].map(id => { const s = SONGS[id]; return `<div class="ns" data-act="play" data-id="${id}" data-ctx="song" data-id="${id}">${cover(s, 44)}<div><b>${s.t}</b><span>${s.a}</span></div>${qb(s.q)}<em>${fmt(s.dur)}</em><button class="ns-p">${ic('play')}</button></div>`; }).join('')}</div></div>
      <div>${secH('热门榜单', '全部', 'data-act="go" data-v="charts"')}<div class="rank-mini">${LISTS.hot().slice(0, 6).map((id, i) => { const s = SONGS[id]; return `<div class="rm" data-act="play" data-id="${id}" data-ctx="song" data-id="${id}"><b class="${i < 3 ? 'top' : ''}">${i + 1}</b>${cover(s, 36)}<div><span>${s.t}</span><small>${s.a}</small></div><em class="${i === 0 ? 'up' : ''}">${i === 0 ? '▲3' : i === 4 ? '▼1' : '—'}</em></div>`; }).join('')}</div></div></div>`
  : D.homeTab === '榜单' ? PAGES.charts.inner() : `<div class="grid-pl blk">${PLAYLISTS.map((x, i) => card(x, { i })).join('')}${PLAYLISTS.slice(0, 4).map((x, i) => card({ ...x, id:x.id + 10, h:x.h + 40 }, { i:i + 8 })).join('')}</div>`}
  <div class="recdiv">${pb(p, 16)}来自${p.n}的推荐</div>
  ${recs.map((t, k) => `${secH(t, '更多')}<div class="hs blk">${[0, 1, 2, 3, 4, 5, 6].map(i => { const s = SONGS[(i * 3 + k * 5) % SONGS.length];
    return k === 1 && p.id !== 'netease' ? `<button class="mood" style="--h:${(i * 52 + 20) % 360}" data-act="playAll"><b>${['开心', '放松', '伤感', '热血', '治愈', '思念', '专注'][i]}</b><i>${['☼', '～', '﹏', '⚡', '♡', '☾', '◎'][i]}</i></button>`
      : k === 3 ? `<div class="mv" data-act="toast" data-msg="播放 MV：${s.t}" data-icon="video"><div class="cv" style="${coverStyle(s.h + 20, s.v)}"><span>${fmt(160 + i * 23)}</span><button>${ic('play')}</button></div><b>${s.t} (Official MV)</b><small>${s.a} · ${(i * 37) % 90 + 3}万次</small></div>`
      : `<div class="alb" data-act="go" data-v="collection" data-id="${i}" data-ctx="playlist"><div class="cv" style="${coverStyle(s.h, s.v)}"></div><i class="disc"></i><b>${k === 2 && p.id === 'netease' ? ['城市流行', '电子', '后摇', '华语独立', 'Lo-fi', 'R&B', '爵士'][i] : s.al}</b><small>${k === 2 && p.id === 'netease' ? `你的偏好 ${[34, 22, 16, 14, 9, 5, 3][i]}%` : s.a}</small></div>`; }).join('')}</div>`).join('')}`;
} };
const LISTS = { hot:() => [0, 2, 4, 5, 17, 7, 11, 16, 14, 12] };

/* ---------- 排行榜 ---------- */
PAGES.charts = { inner:() => PL3.map(p => `<div class="sec-h"><h2>${pb(p, 20)} ${p.n}</h2><span class="dim">每日 10:00 更新</span></div><div class="charts blk">${[['飙升榜', 340], ['热歌榜', 210], ['新歌榜', 30], ['原创榜', 150]].map(([n, h], i) => `<div class="chart" style="--h:${(h + p.c.length * 20) % 360}" data-act="go" data-v="collection" data-id="${i}" data-ctx="playlist">
    <div class="ch-h"><b>${n}</b><small>${100 + i * 50} 首</small><button class="ch-play" data-act="playAll">${ic('play')}</button></div>
    ${[0, 1, 2].map(j => { const s = SONGS[(i * 3 + j + p.id.length) % SONGS.length]; return `<div class="ch-r">${cover(s, 34)}<b>${j + 1}</b><div><span>${s.t}</span><small>${s.a}</small></div></div>`; }).join('')}</div>`).join('')}</div>`).join(''),
  render:() => `${pageHead('排行榜', '网易云 / QQ / 酷狗 官方榜单，悬停卡片可直接播放整榜')}${PAGES.charts.inner()}` };

/* ---------- 歌单广场 ---------- */
const TAGS = { 场景:['学习', '运动', '通勤', '睡前', '咖啡馆', '旅行', '夜晚'], 风格:['流行', '古风', '电子', '摇滚', '民谣', '说唱', '爵士', '后摇'], 语言:['华语', '欧美', '日语', '韩语', '粤语'] };
PAGES.square = { render:() => `${pageHead('歌单广场', `${pb(plat(), 16)} ${plat().n}`, seg(['推荐', '最新', '最热'], D.sqSort, 'sqSort'))}
  <div class="tagbar blk ${D.sqOpen ? 'open' : ''}"><button class="tg ${D.sqTag === '全部' ? 'on' : ''}" data-act="sqTag" data-v="全部">全部</button>${Object.entries(TAGS).map(([g, ts]) => `<span class="tg-g">${g}</span>${ts.map(t => `<button class="tg ${D.sqTag === t ? 'on' : ''}" data-act="sqTag" data-v="${t}">${t}</button>`).join('')}`).join('')}<button class="tg-more" data-act="sqOpen">${D.sqOpen ? '收起' : '展开'}${ic(D.sqOpen ? 'up' : 'down')}</button></div>
  <div class="grid-pl blk" key="${D.sqTag}${D.sqSort}">${[...PLAYLISTS, ...PLAYLISTS.map(x => ({ ...x, id:x.id + 20, h:(x.h + 70) % 360, t:x.t.split(' · ')[0] + ' · ' + D.sqTag }))].map((x, i) => card(x, { i, plat:D.plat })).join('')}</div>
  <div class="loadmore"><i class="spinner sm"></i>加载更多…</div>` };
ACT.sqTag = d => { D.sqTag = d.v; D._stag = true; render(); }; ACT.sqSort = d => { D.sqSort = d.v; D._stag = true; render(); }; ACT.sqOpen = () => { D.sqOpen = !D.sqOpen; render(); };

/* ---------- 合集详情（歌单 / 专辑 / 榜单） ---------- */
PAGES.collection = { render:a => {
  const my = MY.find(x => x.id === a.id), pl = my || PLAYLISTS[a.id % PLAYLISTS.length], liked = a.id === 100;
  const ids = liked ? [...D.liked].concat([2, 3, 5, 8, 9, 11]) : SONGS.map(s => s.id).filter((x, i) => (i * 7 + pl.h) % 3 !== 0);
  return `<div class="coll" style="--h:${pl.h}">
    <div class="coll-bg"><div style="${coverStyle(pl.h, pl.v)}"></div></div>
    <div class="coll-h"><div class="cv cv-hero" style="${coverStyle(pl.h, pl.v)}">${liked ? `<span class="big-heart">${ic('heartf')}</span>` : ''}</div>
      <div class="coll-i"><small>${my ? '我的歌单' : '歌单'} · ${pb(platBy(my ? 'netease' : D.plat), 16)} ${my ? '本地 + 云同步' : plat().n}</small><h1>${pl.t}</h1>
        <div class="coll-m"><span class="avatar xs">${(pl.by || '栗')[0]}</span>${pl.by || '阿栗'} · ${ids.length} 首 · ${pl.pc ? pl.pc + ' 次播放 · ' : ''}更新于 2026.11.01</div>
        <p class="coll-d">适合在夜里一个人走路时听。霓虹、雨声、合成器和一点点想念。</p>
        <div class="coll-a"><button class="btn pri" data-act="playAll">${ic('play')}播放全部</button><button class="btn sec" data-act="toast" data-msg="已加入队列 · ${ids.length} 首" data-icon="queue">${ic('queue')}加入队列</button><button class="btn sec" data-act="toast" data-msg="已收藏歌单" data-icon="heartf">${ic('heart')}收藏</button><button class="btn sec" data-act="toast" data-msg="已加入下载 · ${ids.length} 首" data-icon="download">${ic('download')}下载全部</button><button class="btn sec ic-only" data-act="ctxBtn" data-id="0">${ic('more')}</button></div></div></div>
    <div class="coll-sticky">${cover({ h:pl.h, v:pl.v }, 32)}<b>${pl.t}</b><button class="btn pri sm" data-act="playAll">${ic('play')}播放全部</button><div class="cs-search">${ic('search')}<input placeholder="在歌单内搜索"></div></div>
    ${selBar()}${songTable(ids, { list:'coll', grey:s => s.id === 6 })}</div>`;
} };
PAGES.artist = { render:a => { const s = SONGS[a.id || 0], mine = [...new Set(SONGS.filter(x => x.a === s.a).concat(SONGS.slice(0, 10)))].slice(0, 8);
  return `<div class="coll artist" style="--h:${s.h}"><div class="coll-bg sharp"><div style="${coverStyle(s.h, 1)}"></div></div>
    <div class="coll-h"><div class="cv cv-hero round" style="${coverStyle(s.h, 1)}"></div><div class="coll-i"><small>艺术家 · ${pb(platBy(pidOf(s.id)), 16)}</small><h1>${s.a}</h1><div class="coll-m">12.4 万关注 · 3 张专辑 · 本月 38 万次聆听</div>
      <div class="coll-a"><button class="btn pri" data-act="playAll">${ic('play')}播放热门</button><button class="btn sec" data-act="toast" data-msg="已关注 ${s.a}" data-icon="heartf">${ic('heart')}关注</button><button class="btn sec" data-act="playAll">${ic('wave')}歌手电台</button></div></div></div>
    ${secH('热门歌曲')}${songTable(mine.map(x => x.id), { sortable:false })}
    ${secH('专辑')}<div class="hs">${[s.al, '现场 · 2025', '单曲合集', '远光 (Deluxe)'].map((t, i) => `<div class="alb" data-act="go" data-v="collection" data-id="${i}"><div class="cv" style="${coverStyle(s.h + i * 30, i)}"></div><i class="disc"></i><b>${t}</b><small>${2026 - i}</small></div>`).join('')}</div>
    ${secH('相似艺术家')}<div class="hs">${[...new Set(SONGS.map(x => x.a))].filter(x => x !== s.a).slice(0, 7).map((x, i) => `<div class="art" data-act="go" data-v="artist" data-id="${SONGS.find(y => y.a === x).id}"><div class="cv" style="${coverStyle(i * 50 + 20, 1)}"></div><b>${x}</b></div>`).join('')}</div></div>`; } };

/* ---------- 搜索结果 ---------- */
PAGES.search = { render:a => {
  const q = a.q || D.q, ql = q.toLowerCase(), H = hl(q);
  let res = SONGS.filter(s => (s.t + s.a + s.al).toLowerCase().includes(ql)); const exact = res.length > 0; if (!exact) res = [];
  if (D.sPlat !== 'all') res = res.filter(s => pidOf(s.id) === D.sPlat);
  const counts = PL3.map(p => SONGS.filter(s => (s.t + s.a + s.al).toLowerCase().includes(ql) && pidOf(s.id) === p.id).length + 8);
  const types = ['单曲', '歌手', '专辑', '歌单', '歌词', 'MV'], unsupported = D.sType === '歌词' ? ['kugou'] : D.sType === 'MV' ? ['kugou'] : [];
  const artist = SONGS.find(s => s.a.toLowerCase().includes(ql));
  let body;
  if (!exact) body = empty('search', `没有找到「${q}」`, '换个关键词，或者切换到其他平台试试', `<div class="chips">${HOT.slice(0, 5).map(h => `<button class="tg" data-act="sq" data-q="${h}">${h}</button>`).join('')}</div>`);
  else if (D.sType === '单曲') body = `${artist ? `<div class="best blk" data-act="go" data-v="artist" data-id="${artist.id}"><div class="cv" style="${coverStyle(artist.h, 1)}"></div><div><small>最佳匹配 · 艺术家</small><b>${H(artist.a)}</b><span>${SONGS.filter(s => s.a === artist.a).length} 首 · 3 张专辑</span></div><button class="hc-play" data-act="playAll">${ic('play')}</button></div>` : ''}
    ${selBar()}${songTable(res.map(s => s.id), { hl:H, list:'search' })}<div class="loadmore"><i class="spinner sm"></i>滚动加载下一页 · 每页 40 条</div>`;
  else if (D.sType === '歌词') body = unsupported.includes(D.sPlat) ? empty('info', '酷狗暂不支持按歌词搜索', '已为你显示其他平台的结果', '') : res.map((s, i) => `<div class="lyr-hit" data-act="play" data-id="${s.id}">${cover(s, 44)}<div><b>${s.t} · ${s.a}</b><p>…${H(LYRICS[i % LYRICS.length].o)}，${LYRICS[(i + 1) % LYRICS.length].o}…</p></div>${pb(platBy(pidOf(s.id)), 16)}</div>`).join('');
  else if (D.sType === '歌手') body = `<div class="grid-art">${[...new Set(res.map(s => s.a))].map((x, i) => `<div class="art" data-act="go" data-v="artist" data-id="${SONGS.find(y => y.a === x).id}"><div class="cv" style="${coverStyle(i * 50 + 20, 1)}"></div><b>${H(x)}</b><small>12 万关注</small></div>`).join('')}</div>`;
  else if (D.sType === 'MV') body = `<div class="grid-mv">${res.concat(res).slice(0, 8).map((s, i) => `<div class="mv" data-act="toast" data-msg="播放 MV" data-icon="video"><div class="cv" style="${coverStyle(s.h + 20, s.v)}"><span>${fmt(150 + i * 17)}</span><button>${ic('play')}</button></div><b>${H(s.t)}</b><small>${s.a}</small></div>`).join('')}</div>`;
  else body = `<div class="grid-pl">${(D.sType === '专辑' ? res.map(s => ({ id:s.id, t:s.al, n:10, h:s.h, v:s.v, by:s.a })) : PLAYLISTS).map((x, i) => card(x, { i })).join('')}</div>`;
  return `<div class="srch-h"><h1>「${q}」</h1><span class="dim">共 ${counts.reduce((a, b) => a + b, 0)} 条结果</span></div>
    <div class="srch-f blk"><div class="stype">${types.map(t => `<button class="${D.sType === t ? 'on' : ''}" data-act="sType" data-v="${t}">${t}</button>`).join('')}</div>
      <div class="splat"><button class="${D.sPlat === 'all' ? 'on' : ''}" data-act="sPlat" data-v="all">全部平台<small>${counts.reduce((a, b) => a + b, 0)}</small></button>${PL3.map((p, i) => `<button class="${D.sPlat === p.id ? 'on' : ''} ${unsupported.includes(p.id) ? 'na' : ''}" data-act="sPlat" data-v="${p.id}" title="${unsupported.includes(p.id) ? `${p.n}不支持${D.sType}搜索` : ''}">${pb(p, 16)}${p.n.replace('音乐', '')}<small>${unsupported.includes(p.id) ? '不支持' : counts[i]}</small></button>`).join('')}</div></div>
    <div class="rel">${ic('trend')}相关搜索 ${[`${q} 现场`, `${q} 伴奏`, artist ? artist.a : '后摇', `${q} 翻唱`].map(x => `<button data-act="sq" data-q="${x}">${x}</button>`).join('')}</div>
    <div class="srch-b" key="${D.sType}${D.sPlat}">${body}</div>`;
} };

/* ---------- 收藏 / 本地 / 最近 ---------- */
PAGES.favorites = { render:() => `${pageHead('收藏', `${D.liked.size + 6} 首 · 跨平台 · 已同步`, `<button class="btn sec sm" data-act="scanDupes">${ic('layers')}扫描重复项</button><button class="btn pri sm" data-act="playAll">${ic('play')}播放全部</button>`)}
  <div class="toolbar"><div class="tsearch">${ic('search')}<input placeholder="筛选收藏"></div>${seg(['全部', '已下载', '无损', '本地'], '全部', 'toast')}<span class="dim r">排序：${D.libSort}</span></div>
  ${selBar()}${songTable([...D.liked, 2, 3, 5, 8, 9, 11], { list:'fav', extra:['加入时间', (s, i) => `<span class="dim">${['今天', '昨天', '3 天前', '11-01', '10-28', '10-20', '10-02', '09-18', '09-02', '08-11', '07-20'][i % 11]}</span>`] })}` };
ACT.scanDupes = () => { D.dupes = true; D.rpOpen = true; D.rp = 'dupes'; render(); toast('找到 3 组重复，已在右侧列出', 'layers'); };
PAGES.local = { render:() => `${pageHead('本地音乐', '24 首 · 1 小时 26 分 · 3.2 GB', `<button class="btn sec sm" data-act="toast" data-msg="已打开文件夹选择器" data-icon="folder">${ic('plus')}添加目录</button><button class="btn pri sm" data-act="scanLocal">${ic('refresh')}重新扫描</button>`)}
  <div class="dirs">${[['D:\\Music', 186, true], ['E:\\无损', 64, true], ['\\\\NAS\\share\\music', 0, false]].map(([p, n, ok]) => `<div class="dir ${ok ? '' : 'bad'}">${ic('folder')}<div><b>${p}</b><small>${ok ? `${n} 首 · 上次扫描 2 小时前` : '无法访问，请检查网络或权限'}</small></div><button class="ib" data-act="toast" data-msg="已移除目录" data-icon="trash">${ic('close')}</button></div>`).join('')}
    ${D.scanning ? `<div class="scanbar"><i style="width:${D.scanning}%"></i><span>正在扫描 ${Math.round(D.scanning * 2.5)}/250 · 修复 2 个乱码标签</span></div>` : ''}</div>
  <div class="toolbar">${seg(['歌曲', '专辑', '歌手', '文件夹'], D.localView, 'localView')}<span class="dim r">拖拽音频文件到窗口即可导入</span></div>
  ${D.localView === '歌曲' ? selBar() + songTable(SONGS.map(s => s.id).sort((a, b) => SONGS[a].t.localeCompare(SONGS[b].t, 'zh')), { list:'local', extra:['格式', (s, i) => `<span class="fmt">${['FLAC', 'MP3', 'FLAC', 'M4A', 'WAV'][i % 5]}</span>`] })
  : D.localView === '专辑' ? `<div class="grid-pl">${[...new Set(SONGS.map(s => s.al))].map((al, i) => { const s = SONGS.find(x => x.al === al); return card({ id:i, t:al, n:SONGS.filter(x => x.al === al).length, h:s.h, v:s.v, by:s.a }, { i }); }).join('')}</div>`
  : D.localView === '歌手' ? `<div class="grid-art">${[...new Set(SONGS.map(s => s.a))].map((a, i) => `<div class="art" data-act="go" data-v="artist" data-id="${SONGS.find(y => y.a === a).id}"><div class="cv" style="${coverStyle(i * 50 + 20, 1)}"></div><b>${a}</b><small>${SONGS.filter(s => s.a === a).length} 首</small></div>`).join('')}</div>`
  : `<div class="tree">${['D:\\Music\\华语', 'D:\\Music\\欧美', 'D:\\Music\\Live', 'E:\\无损\\2026'].map((f, i) => `<div class="tree-it">${ic('folder')}<b>${f}</b><span>${12 + i * 7} 首</span>${ic('right')}</div>`).join('')}</div>`}` };
ACT.localView = d => { D.localView = d.v; D._stag = true; render(); };
ACT.scanLocal = () => { D.scanning = 1; render(); const t = setInterval(() => { D.scanning += 9; if (D.scanning >= 100) { clearInterval(t); D.scanning = 0; toast('扫描完成 · 新增 3 首', 'check'); } render(); }, 160); };
PAGES.history = { render:() => `${pageHead('最近播放', '保留最近 1000 条', `<button class="btn sec sm" data-act="dlg" data-v="clearHist">${ic('trash')}清空</button>`)}
  ${[['今天', [D.cur, 5, 11, 2, 16]], ['昨天', [7, 18, 20, 9, 1]], ['更早', [3, 14, 22, 6]]].map(([g, ids]) => `<div class="grp-t">${g}</div>${songTable(ids, { sortable:false, extra:['播放', (s, i) => `<span class="dim">${['21:42', '21:38', '20:15', '19:02', '09:12'][i % 5]} · ${3 + i} 次</span>`] })}`).join('')}` };

/* ---------- 统计 ---------- */
PAGES.stats = { render:() => { const curve = Array.from({ length:25 }, (_, i) => 20 + 60 * Math.exp(-((i - 22) ** 2) / 8) + 30 * Math.exp(-((i - 13) ** 2) / 10) + 18 * Math.exp(-((i - 1) ** 2) / 3));
  return `${pageHead('听歌统计', '只在本机计算', seg(['近 7 天', '近 30 天', '近 90 天', '全部'], D.statRange, 'statRange'))}
  <div class="st-cards blk">${[['117', '首', '歌曲', 'music'], ['105', '张', '专辑', 'album'], ['106', '位', '歌手', 'user'], ['96.4', '小时', '累计时长', 'clock'], ['216', '次', '累计播放', 'wave'], ['12', '天', '连续聆听', 'flame']].map(([v, u, n, i], k) => `<div class="stc" style="--d:${k * 50}ms"><b>${v}<small>${u}</small></b><span>${n}</span>${ic(i)}</div>`).join('')}</div>
  <div class="st-grid blk">
    <div class="stp"><h3>聆听足迹<small>近 90 天</small></h3><div class="heat">${Array.from({ length:91 }, (_, i) => { const v = (Math.sin(i * 1.7) + Math.sin(i * .37) + 2) / 4; return `<i style="--v:${Math.round(v * v * 100)}%;--d:${i * 5}ms" title="${v * 3 | 0} 小时"></i>`; }).join('')}</div></div>
    <div class="stp"><h3>播放时段<small>高峰 22:00</small></h3><svg class="curve" viewBox="0 0 240 100" preserveAspectRatio="none"><defs><linearGradient id="cg" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stop-color="var(--accent)" stop-opacity=".45"/><stop offset="1" stop-color="var(--accent)" stop-opacity="0"/></linearGradient></defs><path d="M0 100 ${curve.map((v, i) => `L${i * 10} ${100 - v}`).join(' ')} L240 100Z" fill="url(#cg)"/><path d="${curve.map((v, i) => `${i ? 'L' : 'M'}${i * 10} ${100 - v}`).join(' ')}" fill="none" stroke="var(--accent)" stroke-width="2" vector-effect="non-scaling-stroke"/></svg><div class="ax">${['00', '06', '12', '18', '24'].map(x => `<span>${x}</span>`).join('')}</div></div>
    <div class="stp"><h3>音质构成<small>无损占比 88%</small></h3><div class="donut-w"><svg class="donut" viewBox="0 0 42 42">${[[52, 0], [33, 52], [6, 85], [6, 91], [3, 97]].map(([v, o], i) => `<circle cx="21" cy="21" r="15.9" fill="none" stroke-width="5" stroke="var(--accent)" stroke-opacity="${1 - i * .18}" stroke-dasharray="${v} ${100 - v}" stroke-dashoffset="${25 - o}"/>`).join('')}</svg><div class="dn-l">${[['母带', '52%'], ['FLAC', '33%'], ['320K', '6%'], ['128K', '6%'], ['Hi-Res', '3%']].map(([n, v], i) => `<div><i style="opacity:${1 - i * .18}"></i>${n}<b>${v}</b></div>`).join('')}</div></div></div>
    <div class="stp"><h3>平台分布</h3>${PL3.map((p, i) => `<div class="pbar-r">${pb(p, 18)}<span>${p.n}</span><div><i style="width:${[58, 27, 15][i]}%;background:linear-gradient(90deg,${p.c},${p.c2})"></i></div><b>${[58, 27, 15][i]}%</b></div>`).join('')}</div></div>
  <div class="st-tops blk">${['最常听歌曲', '最常听专辑', '最常听歌手'].map((t, k) => `<div class="stp"><h3>${t}</h3>${[0, 1, 2, 3, 4].map(i => { const s = SONGS[(i * 5 + k * 3) % SONGS.length]; return `<div class="top-r ${i ? '' : 'first'}" data-act="play" data-id="${s.id}">${cover(s, i ? 36 : 56, k === 2 ? 'round' : '')}<div><b>${k === 1 ? s.al : k === 2 ? s.a : s.t}</b><small>${s.a}</small></div><em>${[17, 12, 9, 7, 6][i]}<small>次</small></em></div>`; }).join('')}</div>`).join('')}</div>`; } };
ACT.statRange = d => { D.statRange = d.v; D._stag = true; render(); };

/* ---------- 智能歌单：自然语言规则 ---------- */
PAGES.smart = { render:() => { const sp = SMART[D.smartSel] || SMART[0]; const n = 18 + sp.rules.length * 4;
  const chip = (v, opts) => `<button class="rchip" data-act="toast" data-msg="可选：${opts}" data-icon="filter">${v}${ic('down')}</button>`;
  return `${pageHead('智能歌单', '按规则自动生成，只在本机计算，收藏或播放记录变化时实时更新', `<button class="btn pri sm" data-act="newSmart">${ic('plus')}新建智能歌单</button>`)}
  <div class="smart">
    <div class="sm-list">${SMART.map((x, i) => `<button class="${i === D.smartSel ? 'on' : ''}" data-act="goSmart" data-i="${i}">${ic('sparkle')}<div><b>${x.t}</b><small>${x.n} 首 · ${x.rules.length} 条规则</small></div></button>`).join('')}</div>
    <div class="sm-ed"><div class="sm-name"><input value="${sp.t}"><span class="dim">实时预览 · <b class="acc-t">${n}</b> 首匹配</span></div>
      <div class="rules">
        <div class="rule"><span>从</span>${chip('收藏与最近播放', '本地音乐 / 收藏 / 最近播放 / 指定歌单')}<span>中挑选</span></div>
        <div class="rule"><span class="and">并且</span><span>来源是</span>${PL3.map(p => `<button class="rchip on">${pb(p, 14)}${p.n.replace('音乐', '')}</button>`).join('')}</div>
        <div class="rule"><span class="and">并且</span><span>音质</span>${chip('不低于', '不低于 / 等于 / 不高于')}${chip('SQ 无损', '128k / HQ / SQ / Hi-Res')}<button class="rdel">${ic('close')}</button></div>
        <div class="rule"><span class="and">并且</span><span>播放次数</span>${chip('大于', '大于 / 小于 / 等于')}<input class="rnum" value="5"><span>次</span><button class="rdel">${ic('close')}</button></div>
        <button class="radd" data-act="toast" data-msg="可添加：风格 / 歌手 / 时长 / 入库时间 / 评分" data-icon="plus">${ic('plus')}添加条件</button>
        <div class="rule tail"><span>按</span>${chip('最近播放', '最近播放 / 播放次数 / 入库时间 / 随机')}${chip('降序', '升序 / 降序')}<span>排列，最多</span><input class="rnum" value="50"><span>首</span></div></div>
      <div class="row-btns"><button class="btn sec" data-act="toast" data-msg="已删除" data-icon="trash">删除</button><button class="btn pri" data-act="toast" data-msg="已保存「${sp.t}」" data-icon="check">保存</button></div>
      ${secH(`预览 · ${n} 首`)}${songTable([0, 4, 7, 12, 17, 2, 21, 8], { sortable:false })}</div></div>`; } };
ACT.newSmart = () => { SMART.push({ id:210 + SMART.length, t:'新的智能歌单', n:0, rules:[['pool', '本地音乐']] }); D.smartSel = SMART.length - 1; render(); };

/* ---------- 平台与解析脚本 ---------- */
PAGES.sources = { full:true, render:() => `${pageHead('平台与解析脚本', '先选平台，再选该平台的解析脚本；拖动调整优先级', `<button class="btn sec sm" data-act="toast" data-msg="3 个脚本已是最新" data-icon="refresh">${ic('refresh')}检查更新</button><button class="btn pri sm" data-act="toast" data-msg="可从文件 / 链接 / 粘贴内容导入" data-icon="code">${ic('plus')}导入音源</button>`)}
  <div class="src-grid">${PL3.map(p => `<div class="src-p ${p.id === D.plat ? 'cur' : ''}" style="--pc:${p.c}"><div class="sp-h">${pb(p, 36)}<div><b>${p.n}</b><small>${isIn(p.id) ? '已登录 · ' + D.login[p.id] : '未登录'}</small></div>${p.id === D.plat ? '<span class="badge acc">当前</span>' : `<button class="btn sec xs" data-act="setPlat" data-v="${p.id}">设为当前</button>`}</div>
    ${scriptsOf(p.id).sort((a, b) => b.ok - a.ok).map((s, i) => `<div class="sp-r"><i class="drag-h">${ic('drag')}</i><b class="no">${i + 1}</b><div><b>${s.n} <em>v${s.v}</em></b><small>${s.q.map(qb).join(' ')} · 成功率 ${s.ok}%</small></div>${sig(s.ms)}<span class="ms">${s.ms}ms</span>${sw('src' + s.id + p.id, D.set['src' + s.id + p.id] !== false)}</div>`).join('')}</div>`).join('')}</div>
  <div class="note">${ic('info')}<span>内置音源默认关闭。解析脚本由你自行导入并对其合法性负责，Lyra 只负责调度和播放。智能换源规则在「设置 → 播放与音质」。</span></div>` };
PAGES.notfound = { render:() => empty('compass', '页面走丢了', '这个页面不存在或已被移动', `<button class="btn pri" data-act="go" data-v="discover">回到推荐</button>`) };
